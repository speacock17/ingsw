package ingsw.server.postgreDAO;

import ingsw.server.interfacceDAO.MittenteUtenteDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class MittenteUtentePostgreImpl implements MittenteUtenteDAO {
    final JdbcTemplate jdbcTemplate;

    @Autowired
    public MittenteUtentePostgreImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /*
        Create table MittenteU(
    Mittente varchar(50) NOT NULL,
    IdAvviso integer NOT NULL,
     */

    @Override
    public void scriveAvviso(String username, Integer idAvviso) {
        jdbcTemplate.update("INSERT INTO MittenteU VALUES (?, ?)", username, idAvviso);
    }
}
