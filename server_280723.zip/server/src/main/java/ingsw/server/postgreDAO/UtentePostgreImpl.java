package ingsw.server.postgreDAO;

import ingsw.server.interfacceDAO.UtenteDAO;
import ingsw.server.springDataMapper.SingleStringDataMapper;
import ingsw.server.springDataMapper.StringDataMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UtentePostgreImpl implements UtenteDAO {
    final JdbcTemplate jdbcTemplate;

    @Autowired
    public UtentePostgreImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /*
        Create table Utente(
    Nome varchar(50) NOT NULL,
    Cognome varchar(50) NOT NULL,
    Username varchar(50) NOT NULL,
    Pass varchar(50) NOT NULL,
    Ruolo tipoUtente NOT NULL,
    PrimoAccesso bool DEFAULT false,
    */

    @Override
    public void inserisciUtente(String nome, String cognome, String username, String password, String ruolo) {
        jdbcTemplate.update("INSERT INTO UTENTE VALUES (?, ?, ?, ?, ?)",
                nome, cognome, username, password, ruolo);
    }

    @Override
    public void modificaNomeUtente(String username, String nome) {
        jdbcTemplate.update("UPDATE UTENTE SET Nome = ? where Username = ?", nome, username);
    }

    @Override
    public void modificaCognomeUtente(String username, String cognome) {
        jdbcTemplate.update("UPDATE UTENTE SET Cognome = ? where Username = ?", cognome, username);
    }

    @Override
    public void modificaUsernameUtente(String username, String newUsername) {
        jdbcTemplate.update("UPDATE UTENTE SET Username = ? where Username = ?", newUsername, username);
    }

    @Override
    public void modificaPasswordUtente(String username, String password) {
        jdbcTemplate.update("UPDATE UTENTE SET Pass = ? where Username = ?", password, username);
    }

    @Override
    public void modificaRuoloUtente(String username, String ruolo) {
        jdbcTemplate.update("UPDATE UTENTE SET Ruolo = ? where Username = ?", ruolo, username);
    }

    @Override
    public void modificaPrimoAccessoUtente(String username, Boolean accesso) {
        jdbcTemplate.update("UPDATE UTENTE SET PrimoAccesso = ? WHERE Username = ?", accesso, username);
    }

    @Override
    public void eliminaUtenteByUsername(String username) {
        jdbcTemplate.update("DELETE FROM UTENTE WHERE Username = ?", username);
    }

    @Override
    public void eliminaUtentiByRuolo(String ruolo) {
        jdbcTemplate.update("DELETE FROM UTENTE WHERE Ruolo = ?::tipoUtente", ruolo);
    }

    @Override
    public void eliminaTuttiUtenti() {
        jdbcTemplate.update("DELETE FROM UTENTE");
    }

    @Override
    public String recuperaUtenteNoPassword(String username) {
        List<String> utente = jdbcTemplate.query("SELECT Nome, Cognome, Username, Ruolo FROM UTENTE WHERE Username = ?", new StringDataMapper(), username);
        return utente.get(0);
    }

    @Override
    public String recuperaPasswordByUsername(String username) {
        return jdbcTemplate.queryForObject("SELECT Pass FROM UTENTE WHERE Username = ?", String.class, username);
    }

    @Override
    public Boolean recuperaAccessoByUsername(String username) {
        return jdbcTemplate.queryForObject("SELECT PrimoAccesso FROM UTENTE WHERE Username = ?", Boolean.class, username);
    }

    @Override
    public String recuperaUtenteByUsername(String username){
        return jdbcTemplate.queryForObject("SELECT Username FROM UTENTE WHERE Username = ?", String.class, username);
    }

    @Override
    public String recuperaRuoloByUsername(String username) {
        return jdbcTemplate.queryForObject("SELECT Ruolo FROM UTENTE WHERE Username = ?", String.class, username);
    }

    @Override
    public List<String> recuperaUtentiByRuolo(String ruolo) {
        return jdbcTemplate.query("SELECT Nome, Cognome, Username, Ruolo FROM UTENTE WHERE Ruolo = ?::tipoUtente",
                new StringDataMapper(), ruolo);
    }

    @Override
    public List<String> recuperaUsernameTuttiUtenti() {
        return jdbcTemplate.query("SELECT Username FROM UTENTE", new SingleStringDataMapper());
    }

    @Override
    public List<String> recuperaTuttiUtenti() {
        return jdbcTemplate.query("SELECT * FROM UTENTE", new StringDataMapper());
    }
}
