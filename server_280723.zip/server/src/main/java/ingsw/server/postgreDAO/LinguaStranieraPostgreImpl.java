package ingsw.server.postgreDAO;

import ingsw.server.interfacceDAO.LinguaStranieraDAO;
import ingsw.server.springDataMapper.StringDataMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class LinguaStranieraPostgreImpl implements LinguaStranieraDAO {
    final JdbcTemplate jdbcTemplate;

    @Autowired
    public LinguaStranieraPostgreImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    /*
    Create table LinguaStraniera(
        Lingua varchar(50) NOT NULL,
        NomeProdotto varchar(100) NOT NULL,
        DescrizioneProdotto varchar(500) NOT NULL,
        ElementoMenu varchar(100) NOT NULL,
     */

    @Override
    public void inserisciLinguaStraniera(String lingua, String nomeProdotto, String descrizioneProd, String elementoMenu) {
        jdbcTemplate.update("INSERT INTO LinguaStraniera VALUES (?,?,?,?)",
                lingua, nomeProdotto, descrizioneProd, elementoMenu);
    }

    @Override
    public void modificaLinguaElemLingStr(String elemMenu, String lingua) {
        jdbcTemplate.update("UPDATE LinguaStraniera SET Lingua = ? WHERE ElementoMenu = ?",
                lingua, elemMenu);
    }

    @Override
    public void modificaNomeLingStr(String elemMenu, String nomeProdotto) {
        jdbcTemplate.update("UPDATE LinguaStraniera SET NomeProdotto = ? WHERE ElementoMenu = ?",
                nomeProdotto, elemMenu);
    }

    @Override
    public void modificaDescrElemMenu(String elemMenu, String descrizioneProd) {
        jdbcTemplate.update("UPDATE LinguaStraniera SET DescrizioneProdotto = ? WHERE ElementoMenu = ?",
                descrizioneProd, elemMenu);
    }

    @Override
    public void eliminaElemMenu(String elemMenu) {
        jdbcTemplate.update("DELETE FROM LinguaStraniera WHERE ElementoMenu = ?", elemMenu);
    }

    @Override
    public void eliminaTuttoMenu() {
        jdbcTemplate.update("DELETE FROM LinguaStraniera");
    }

    @Override
    public String recuperaElemLinguaStr(String elemMenu) {
        List<String> linguaStraniera = jdbcTemplate.query("SELECT * FROM LinguaStraniera WHERE ElementoMenu = ?", new StringDataMapper(), elemMenu);

        if(linguaStraniera.isEmpty()) return null;

        return linguaStraniera.get(0);
    }

    @Override
    public List<String> recuperaTuttaLinguaStraniera() {
        return jdbcTemplate.query("SELECT * FROM LinguaStraniera", new StringDataMapper());
    }
}
