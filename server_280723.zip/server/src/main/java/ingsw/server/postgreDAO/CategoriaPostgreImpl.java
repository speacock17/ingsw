package ingsw.server.postgreDAO;

import ingsw.server.interfacceDAO.CategoriaDAO;
import ingsw.server.springDataMapper.StringDataMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CategoriaPostgreImpl implements CategoriaDAO {
    final JdbcTemplate jdbcTemplate;

    @Autowired
    public CategoriaPostgreImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /*
        Create table Categoria(
    Nome varchar(50) NOT NULL,
    PostoMenu integer DEFAULT NULL,
     */

    @Override
    public void inserisciCategoria(String nome, Integer postoMenu) {
        jdbcTemplate.update("INSERT INTO CATEGORIA VALUES (?, ?)",
                nome, postoMenu);
    }

    @Override
    public void modificaNomeCategoria(String nome, String newName) {
        jdbcTemplate.update("UPDATE CATEGORIA SET Nome = ? WHERE Nome = ?",
                newName, nome);
    }

    @Override
    public void modificaPostoCategoria(String nome, Integer postoMenu) {
        jdbcTemplate.update("UPDATE CATEGORIA SET PostoMenu = ? WHERE Nome = ?",
                postoMenu, nome);
    }

    @Override
    public void eliminaCategoriaByNome(String nome) {
        jdbcTemplate.update("DELETE FROM CATEGORIA WHERE Nome = ?", nome);
    }

    @Override
    public void eliminaTutteCategorie() {
        jdbcTemplate.update("DELETE FROM CATEGORIA");
    }

    @Override
    public Integer recuperaUltimoPosto() {
        return jdbcTemplate.queryForObject("SELECT PostoMenu FROM CATEGORIA WHERE PostoMenu = (SELECT max(PostoMenu) FROM CATEGORIA)",
                Integer.class);
    }

    @Override
    public String recuperaCategoriaByNome(String nome) {
        List<String> categoria = jdbcTemplate.query("SELECT * FROM CATEGORIA WHERE Nome = ?", new StringDataMapper(), nome);

        if(categoria.isEmpty()) return null;

        return categoria.get(0);
    }

    @Override
    public List<String> recuperaTutteCategorie() {
        return jdbcTemplate.query("SELECT * FROM CATEGORIA ORDER BY PostoMenu",
                new StringDataMapper());
    }
}
