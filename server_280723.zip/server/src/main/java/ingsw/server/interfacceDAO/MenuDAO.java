package ingsw.server.interfacceDAO;

import java.util.List;

public interface MenuDAO {
    /*Nome varchar(100) NOT NULL,
    Descrizione varchar(500) NOT NULL,
    Costo float NOT NULL,
    Allergeni varchar(500) NOT NULL,
    Categoria varchar(50) DEFAULT NULL,
    PostoCategoria integer DEFAULT NULL*/

    public void inserisciMenu(String nome,
                                  String descrizione,
                                  Float costo,
                                  String allergeni,
                                  String categoria);
    public void modificaNomeMenu(String nome, String newNome);
    public void modificaDescrizioneMenu(String nome, String descrizione);
    public void modificaCostoMenu(String nome, Float costo);
    public void modificaAllergeniMenu(String nome, String allergeni);
    public void modificaPostoCategoriaMenu(String nome, Integer postoCategoria);
    public void modificaCategoriaMenu(String nome, String categoria);
    public void eliminaMenuByNome(String nome);
    public void eliminaTuttoMenu();
    public List<String> recuperaTuttoMenu();
    public String recuperaMenuByNome(String nome);
    public String recuperaNomeMenuByNome(String nome);
    public List<String> recuperaMenuByCategoria(String categoria);
    public Integer recuperaPostoMenuByCategoria(String categoria);
    public List<String> recuperaElementiMenuSenzaCategoria();
}
