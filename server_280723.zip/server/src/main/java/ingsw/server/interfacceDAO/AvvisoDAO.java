package ingsw.server.interfacceDAO;

import java.util.List;

public interface AvvisoDAO {
    /*
        Create table Avviso(
    IdAvviso integer NOT NULL,
    Oggetto varchar(50) NOT NULL,
    Testo varchar(500) NOT NULL,
    DataCreazione date NOT NULL default current_date,
    */

    public void inserisciAvviso(String Oggetto, String Testo);
    public void eliminaAvvisoById(Integer idAvviso);
    public void eliminaTuttiAvvisi();
    public String recuperaAvvisoById(Integer idAvviso);
    public Integer recuperaIdAvviso(Integer idAvviso);
    public Integer recuperaIdUltimoAvviso();
    public List<String> recuperaTuttiAvvisi();

}
