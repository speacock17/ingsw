package ingsw.server.interfacceDAO;

import java.sql.ResultSet;
import java.util.List;

public interface OrdineDAO {
    /*
        Create table Ordine(
        IdOrdine integer NOT NULL,
        NumeroTavolo integer NOT NULL,
        Prodotto varchar(100) NOT NULL,
    */
    public void inserisciOrdine(Integer numeroTavolo, String prodotto);
    public void modificaNumTavoloById(Integer idOrdine, Integer numeroTavolo);
    public void eliminaOrdiniByTavolo(Integer numTavolo);
    public void eliminaOrdineById(Integer idOrdine);
    public void eliminaTuttiOrdini();
    public String recuperaUltimoOrdine();
    public Integer recuperaIdUltimoOrdine();
    public Integer recuperaNumeroTavolo(Integer numeroTavolo);
    public String recuperaOrdineById(Integer idOrdine);
    public String recuperElemMenuOrdineById(Integer idOrdine);
    public List<String> recuperaTuttiOrdini();
    public List<String> recuperaOrdiniByNumTavolo(Integer numeroTavolo);
}
