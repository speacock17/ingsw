package ingsw.server.entityDTO.menuDTO;

public class NomeElemMenuDTO {
    private String nome;

    public String getNome() {
        return nome;
    }
}
