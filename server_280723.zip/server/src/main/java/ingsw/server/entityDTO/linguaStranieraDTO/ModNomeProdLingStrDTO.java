package ingsw.server.entityDTO.linguaStranieraDTO;

public class ModNomeProdLingStrDTO {
    private String elementoMenu;
    private String nomeProdotto;

    public String getElementoMenu() {
        return elementoMenu;
    }

    public String getNomeProdotto() {
        return nomeProdotto;
    }
}
