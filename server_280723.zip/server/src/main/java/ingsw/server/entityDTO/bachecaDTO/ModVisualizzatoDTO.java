package ingsw.server.entityDTO.bachecaDTO;

public class ModVisualizzatoDTO {
    private String username;
    private Integer idAvviso;
    private Boolean visualizzato;

    public String getUsername() {
        return username;
    }

    public Integer getIdAvviso() {
        return idAvviso;
    }

    public Boolean getVisualizzato() {
        return visualizzato;
    }
}
