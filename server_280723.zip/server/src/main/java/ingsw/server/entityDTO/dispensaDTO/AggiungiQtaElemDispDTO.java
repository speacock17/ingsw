package ingsw.server.entityDTO.dispensaDTO;

public class AggiungiQtaElemDispDTO {
    private String nome;
    private Float aggiungi;

    public String getNome() {
        return nome;
    }

    public Float getAggiungi() {
        return aggiungi;
    }

    public AggiungiQtaElemDispDTO(String nome, Float aggiungi) {
        this.nome = nome;
        this.aggiungi = aggiungi;
    }
}
