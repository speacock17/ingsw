package ingsw.server.entityDTO.utenteDTO;

public class ModCognomeUtenteDTO {
    String username;
    String cognome;

    public String getUsername() {
        return username;
    }

    public String getCognome() {
        return cognome;
    }
}
