package ingsw.server.entityDTO.dispensaDTO;

public class ModUdMElemDispDTO {
    private String nome;
    private String unitaDiMisura;

    public String getNome() {
        return nome;
    }

    public String getUnitaDiMisura() {
        return unitaDiMisura;
    }
}
