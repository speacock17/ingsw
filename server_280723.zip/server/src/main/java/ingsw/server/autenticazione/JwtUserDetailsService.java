package ingsw.server.autenticazione;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import ingsw.server.interfacceDAO.UtenteDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class JwtUserDetailsService implements UserDetailsService {
    private String password;
    private String ruolo;
    private final UtenteDAO utenteDao;

    @Autowired
    public  JwtUserDetailsService(UtenteDAO utenteDao){
        this.utenteDao = utenteDao;
    }

    private Boolean esisteUtente(String username){
        try {
            String bin = utenteDao.recuperaUtenteByUsername(username);
            return true;
        } catch (DataAccessException e){
            return false;
        }
    }

    private void recuperaPassword(String username){
        try {
            password = utenteDao.recuperaPasswordByUsername(username);
        } catch (DataAccessException e){
            System.out.println(e.getMessage());
        }
    }

    private void recuperaRuolo(String username){
        try {
            ruolo = utenteDao.recuperaRuoloByUsername(username);
        } catch (DataAccessException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public UserDetails loadUserByUsername(final String username) {
        if(!esisteUtente(username))
            throw  new UsernameNotFoundException("User " + username + " not found");
        recuperaPassword(username);
        recuperaRuolo(username);

        String hashedPassword = BCryptPassword.criptaPassword(password);

        return new User(username, hashedPassword, Collections.singletonList(new SimpleGrantedAuthority(ruolo)));
    }
}
