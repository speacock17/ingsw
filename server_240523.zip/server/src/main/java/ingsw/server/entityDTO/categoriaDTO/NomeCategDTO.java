package ingsw.server.entityDTO.categoriaDTO;

public class NomeCategDTO {
    private String nome;

    public String getNome() {
        return nome;
    }
}
