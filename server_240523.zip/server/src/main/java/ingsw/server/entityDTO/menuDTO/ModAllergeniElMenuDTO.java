package ingsw.server.entityDTO.menuDTO;

public class ModAllergeniElMenuDTO {
    private String nome;
    private String allergeni;

    public String getNome() {
        return nome;
    }

    public String getAllergeni() {
        return allergeni;
    }
}
