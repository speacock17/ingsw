package ingsw.server.openFoodData;

import org.json.JSONObject;

public class LeggiJSON {
    public String getDescrizione(JSONObject json){
        try {
            //ottiene l'oggeto json dell'attributo 'product'
            JSONObject productJson = json.getJSONObject("product");

            String risultato = "nomeProdotto = ";

            if(productJson.has("product_name_it"))
                risultato += productJson.getString("product_name_it");
            else risultato += productJson.getString("product_name");

            risultato += "\ndescrizione = ";

            if(productJson.has("ingredients_text_it"))
                risultato += productJson.getString("ingredients_text_it");
            else risultato += productJson.getString("ingredients_text");

            return risultato;
        } catch (Exception e){
            System.out.println(e.getMessage());
            return null;
        }
    }
}
