package ingsw.server.entityDTO.dispensaDTO;

public class ModQtaElemDispDTO {
    private String nome;
    private Float quantita;

    public String getNome() {
        return nome;
    }

    public Float getQuantita() {
        return quantita;
    }
}
