package ingsw.server.factoryLogic;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;


public class LeggiModelXML {
    public static String getStorage(String modelName){
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();

            String xmlPath = "modelConfig/" + modelName + "Model.xml";
            String progettoPath = System.getProperty("user.dir");
            Document doc = db.parse(new File(progettoPath, xmlPath));

            doc.getDocumentElement().normalize();
            NodeList nodi = doc.getElementsByTagName("data");

            for (int i = 0; i < nodi.getLength(); i++) {
                Node nodoItem = nodi.item(i);
                if (nodoItem.getNodeType() == Node.ELEMENT_NODE) {
                    Element elemento = (Element) nodoItem;
                    if(elemento.getElementsByTagName("entity").item(0).getTextContent().equals(modelName))
                        return elemento.getElementsByTagName("storage").item(0).getTextContent();
                    else{
                        System.out.println("campo entity non corrisponde al model name");
                        return null;
                    }
                }
            }
            System.out.println("Errore in lettura");
            return null;
        } catch (ParserConfigurationException | SAXException | IOException e){
            System.out.println(e.getMessage());
            return null;
        }
    }
}
