package ingsw.server.interfacceDAO;

import java.util.List;

public interface BachecaDAO {
    /*
        Create table Bacheca(
    Visualizzato boolean NOT NULL,
    Nascosto boolean NOT NULL,
    IdAvviso integer NOT NULL,
    Destinatario varchar(50) NOT NULL,
     */
    public void inserisciBacheca(Boolean visualizzato, Boolean nascosto, Integer idAvviso, String destinatario);
    public void modificaVisualizzato(Boolean visualizzato, Integer idAvviso, String destinatario);
    public void modificaNascosto(Boolean nascosto, Integer idAvviso, String destinatario);
    public void eliminaBachecaByUsername(String destinatario);
    public void eliminaTuttaBacheca();
    public List<String> recuperaBachecaByDestinatario(String destinatario);
    public List<String> recuperaVisibili(String destinatario);
    public List<String> recuperaNascosti(String destinatario);
    public List<String> recuperaVisti(String destinatario);
    public List<String> recuperaVistiNascosti(String destinatario);
    public List<String> recuperaTuttaBacheca();
}
