package ingsw.server.interfacceDAO;

public interface MittenteDispensaDAO {
    /*
        Create table MittenteD(
    Mittente varchar(50) NOT NULL,
    IdAvviso integer NOT NULL,
    */
    public void generaAvviso(String elemento, Integer idAvviso);
}
