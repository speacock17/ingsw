package ingsw.server.postgreDAO;

import ingsw.server.interfacceDAO.DispensaDAO;
import ingsw.server.springDataMapper.StringDataMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class DispensaPostgreImpl implements DispensaDAO {
    final JdbcTemplate jdbcTemplate;

    @Autowired
    public DispensaPostgreImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /*
        Create table Dispensa(
    Nome varchar(50) NOT NULL,
    Descrizione varchar(500) NOT NULL,
    CostoAcquisto float NOT NULL,
    UdM UnitaDiMisura NOT NULL,
    Quantita float NOT NULL,
    SogliaCritica float NOT NULL,
    */

    @Override
    public void inserisciDispensa(String nome, String descrizione, Float costoAcq, String unitaDiMisura, Float quantita, Float sogliaCritica) {
        jdbcTemplate.update("INSERT INTO DISPENSA VALUES(?,?,?,?,?,?)",
                nome, descrizione, costoAcq, unitaDiMisura, quantita, sogliaCritica);
    }

    @Override
    public void modificaNomeDispensa(String nome, String newNome) {
        jdbcTemplate.update("UPDATE DISPENSA SET Nome = ? WHERE Nome = ?",
                newNome, nome);
    }

    @Override
    public void modificaDescrizioneDispensa(String nome, String descrizione) {
        jdbcTemplate.update("UPDATE DISPENSA SET Descrizione = ? WHERE Nome = ?",
                descrizione, nome);
    }

    @Override
    public void modificaCostoAcquistoDispensa(String nome, Float costoAcq) {
        jdbcTemplate.update("UPDATE DISPENSA SET CostoAcquisto = ? WHERE Nome = ?",
                costoAcq, nome);
    }

    @Override
    public void modificaUnitaDiMisuraDispensa(String nome, String unitaDiMisura) {
        jdbcTemplate.update("UPDATE DISPENSA SET UdM = ? WHERE Nome = ?",
                unitaDiMisura, nome);
    }

    @Override
    public void modificaQuantitaDispensa(String nome, Float quantita) {
        jdbcTemplate.update("UPDATE DISPENSA SET Quantita = ? WHERE Nome = ?",
                quantita, nome);
    }

    @Override
    public void modificaSogliaCriticaDispensa(String nome, Float sogliaCritica) {
        jdbcTemplate.update("UPDATE DISPENSA SET SogliaCritica = ? WHERE Nome = ?",
                sogliaCritica, nome);
    }

    @Override
    public void eliminaDispensaByNome(String nome) {
        jdbcTemplate.update("DELETE FROM DISPENSA WHERE Nome = ?", nome);
    }

    @Override
    public void eliminaTuttaDispensa() {
        jdbcTemplate.update("DELETE FROM DISPENSA");
    }

    @Override
    public String recuperaNomeDispensaByNome(String nome) {
        return jdbcTemplate.queryForObject("SELECT Nome FROM Dispensa WHERE Nome = ?", String.class, nome);
    }

    @Override
    public String recuperaDispensaByNome(String nome) {
        return jdbcTemplate.queryForObject("SELECT * FROM DISPENSA WHERE Nome = ?",
                String.class, nome);
    }

    @Override
    public String recuperaUdMDispensaByNome(String nome){
        return jdbcTemplate.queryForObject("SELECT UdM FROM DISPENSA WHERE Nome = ?", String.class, nome);
    }

    @Override
    public List<String> recuperaTuttaDispensa() {
        return jdbcTemplate.query("SELECT * FROM DISPENSA",
                new StringDataMapper());
    }

    @Override
    public Float recuperaQuantitaDispensaByNome(String nome) {
        return jdbcTemplate.queryForObject("SELECT Quantita FROM DISPENSA WHERE Nome = ?", Float.class, nome);
    }

    @Override
    public Float recuperaSogliaCriticaDispensaByNome(String nome) {
        return jdbcTemplate.queryForObject("SELECT SogliaCritica FROM DISPENSA WHERE Nome = ?", Float.class, nome);
    }
}
