package ingsw.server.entityDTO.ingredientiDTO;

public class NomeElemMenuDTO {
    private String elementoMenu;

    public String getElementoMenu() {
        return elementoMenu;
    }
}
