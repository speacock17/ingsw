package ingsw.server.factoryDAO;

import ingsw.server.factoryLogic.LeggiModelXML;
import ingsw.server.interfacceDAO.LinguaStranieraDAO;
import ingsw.server.postgreDAO.LinguaStranieraPostgreImpl;

public class LinguaStranieraFactory {
    public static LinguaStranieraDAO getImplementation(){
        String storage = LeggiModelXML.getStorage("LinguaStraniera");
        if(storage.equals("PostgreSQL"))
            return new LinguaStranieraPostgreImpl();
        else return null;
    }
}
