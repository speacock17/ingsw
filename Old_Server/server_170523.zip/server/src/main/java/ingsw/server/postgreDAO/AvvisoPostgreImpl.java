package ingsw.server.postgreDAO;

import ingsw.server.interfacceDAO.AvvisoDAO;
import ingsw.server.springDataMapper.StringDataMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class AvvisoPostgreImpl implements AvvisoDAO {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    /*
        Create table Avviso(
    IdAvviso integer NOT NULL,
    Oggetto varchar(50) NOT NULL,
    Testo varchar(500) NOT NULL,
    DataCreazione date NOT NULL default current_date,
    */

    @Override
    public void inserisciAvviso(String oggetto, String testo) {
        jdbcTemplate.update("INSERT INTO Avviso VALUES (nextval('codAvviso'), ?, ?, DEFAULT)", oggetto, testo);
    }

    @Override
    public void eliminaAvvisoById(Integer idAvviso) {
        jdbcTemplate.update("DELETE FROM Avviso WHERE IdAvviso = ?", idAvviso);
    }

    @Override
    public void eliminaTuttiAvvisi() {
        jdbcTemplate.update("DELETE FROM Avviso");
    }

    @Override
    public String recuperaAvvisoById(Integer idAvviso) {
        return jdbcTemplate.queryForObject("SELECT * FROM Avviso WHERE IdAvviso = ?", String.class, idAvviso);
    }

    @Override
    public Integer recuperaIdAvviso(Integer idAvviso){
        return jdbcTemplate.queryForObject("SELECT IdAvviso FROM Avviso WHERE IdAvviso = ?", Integer.class, idAvviso);
    }

    @Override
    public Integer recuperaIdUltimoAvviso() {
        return jdbcTemplate.queryForObject("SELECT IdAvviso FROM Avviso WHERE IdAvviso = (SELECT max(IdAvviso) FROM Avviso)", Integer.class);
    }

    @Override
    public List<String> recuperaTuttiAvvisi() {
        return jdbcTemplate.query("SELECT * FROM Avviso", new StringDataMapper());
    }
}
