package ingsw.server.postgreDAO;

import ingsw.server.interfacceDAO.MittenteDispensaDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class MittenteDispensaPostgreImpl implements MittenteDispensaDAO {
    @Autowired
    JdbcTemplate jdbcTemplate;

    /*
        Create table MittenteD(
    Mittente varchar(50) NOT NULL,
    IdAvviso integer NOT NULL,
    */

    @Override
    public void generaAvviso(String elemento, Integer idAvviso) {
        jdbcTemplate.update("INSERT INTO MittenteD VALUES (?, ?)", elemento, idAvviso);
    }
}
