package ingsw.server.factoryDAO;

import ingsw.server.factoryLogic.LeggiModelXML;
import ingsw.server.interfacceDAO.IngredientiDAO;
import ingsw.server.postgreDAO.IngredientiPostgreImpl;

public class IngredientiFactory {
    public static IngredientiDAO getImplementation(){
        String storage = LeggiModelXML.getStorage("Ingredienti");
        if(storage.equals("PostgreSQL"))
            return new IngredientiPostgreImpl();
        else return null;
    }
}
