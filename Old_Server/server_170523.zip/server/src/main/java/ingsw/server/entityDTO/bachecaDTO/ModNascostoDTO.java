package ingsw.server.entityDTO.bachecaDTO;

public class ModNascostoDTO {
    private String username;
    private Integer idAvviso;
    private Boolean nascosto;

    public String getUsername() {
        return username;
    }

    public Integer getIdAvviso() {
        return idAvviso;
    }

    public Boolean getNascosto() {
        return nascosto;
    }
}
