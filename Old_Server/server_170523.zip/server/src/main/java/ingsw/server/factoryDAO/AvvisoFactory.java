package ingsw.server.factoryDAO;

import ingsw.server.factoryLogic.LeggiModelXML;
import ingsw.server.interfacceDAO.AvvisoDAO;
import ingsw.server.postgreDAO.AvvisoPostgreImpl;

public class AvvisoFactory {
    public static AvvisoDAO getImplementation(){
        String storage = LeggiModelXML.getStorage("Avviso");
        if(storage.equals("PostgreSQL"))
            return new AvvisoPostgreImpl();
        else return null;
    }
}
