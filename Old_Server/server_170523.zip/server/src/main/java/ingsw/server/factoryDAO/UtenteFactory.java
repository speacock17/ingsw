package ingsw.server.factoryDAO;

import ingsw.server.factoryLogic.LeggiModelXML;
import ingsw.server.interfacceDAO.UtenteDAO;
import ingsw.server.postgreDAO.UtentePostgreImpl;
import org.springframework.jdbc.core.JdbcTemplate;

public class UtenteFactory {
    public static UtenteDAO getImplementation(){
        String storage = LeggiModelXML.getStorage("Utente");
        if(storage.equals("PostgreSQL"))
            return new UtentePostgreImpl();
        else
            return null;
    }
}
