package ingsw.server.controller;

import ingsw.server.entityDTO.utenteDTO.LoginFormDTO;
import ingsw.server.factoryDAO.UtenteFactory;
import ingsw.server.interfacceDAO.UtenteDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("controller/utente")
public class LoginController {
    @Autowired
    UtenteDAO dao = UtenteFactory.getImplementation();

    private Boolean esisteUtente(String username){
        try {
            String bin = dao.recuperaUtenteByUsername(username);
            return true;
        } catch (DataAccessException e){
            return false;
        }
    }

    @GetMapping("login")
    public ResponseEntity<String> login(@RequestBody LoginFormDTO input){
        // effettua il login cercando l'username nel database e confontando la password ricevuta con quella effettiva dell'utente
        try {
            if(!esisteUtente(input.getUsername()))
                return ResponseEntity.badRequest().body("Errore: Utente non trovato");

            //recupero la password
            String passwordDB = dao.recuperaPasswordByUsername(input.getUsername());

            // controllo che sia uguale a quella ricevuta dal client
            if(passwordDB.equals(input.getPassword())){
                // controllo primo accesso
                Boolean primoAccesso = dao.recuperaAccessoByUsername(input.getUsername());

                if(primoAccesso)//true
                    return ResponseEntity.ok().body("Successo: Login effettuato");

                // se e' false vuol dire che NON ha mai fatto il primo accesso
                // metto il primo accesso a true

                dao.modificaPrimoAccessoUtente(input.getUsername(), true);
                return ResponseEntity.ok().body("Successo: Primo accesso effettuato");
            }
            // se le password sono diverse
            else return ResponseEntity.badRequest().body("Failure: Password diverse");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
