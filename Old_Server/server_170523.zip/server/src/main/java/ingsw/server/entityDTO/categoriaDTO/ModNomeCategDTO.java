package ingsw.server.entityDTO.categoriaDTO;

public class ModNomeCategDTO {
    private String nome;
    private String newName;

    public String getNome() {
        return nome;
    }

    public String getNewName() {
        return newName;
    }
}
