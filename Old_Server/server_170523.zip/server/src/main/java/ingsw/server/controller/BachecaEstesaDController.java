package ingsw.server.controller;

import ingsw.server.factoryDAO.BachecaEstesaFactory;
import ingsw.server.interfacceDAO.BachecaEstesaDAO;
import ingsw.server.responseBodyBuilder.SendListaStringhe;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("controller/bachecaEstesaD")
public class BachecaEstesaDController{
    BachecaEstesaDAO dao = BachecaEstesaFactory.getImplementation("DISPENSA");

    @GetMapping("mostra/tutto")
    public ResponseEntity<String> mostraTuttaBacheca(){
        // restituisce una stringa elencata con tutti i valori dei record in bacheca
        try{
            List<String> lista = dao.recuperaTuttaBacheca();
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("mostra/utente/tutti")
    public ResponseEntity<String> mostraBachecaUtente(@RequestParam(value = "username") String username){
        // restituisce una stringa elencata con tutti i valori dei record in bacheca DI UN UTENTE
        try{
            List<String> lista = dao.recuperaBachecaByDestinatario(username);
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("mostra/utente/visibili")
    public ResponseEntity<String> mostraBachecaVisibiliUtente(@RequestParam(value = "username") String username){
        // restituisce una stringa elencata con i record VISIBILI in bacheca DI UN UTENTE
        try{
            List<String> lista = dao.recuperaVisibiliByDestinatario(username);
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("mostra/utente/nascosti")
    public ResponseEntity<String> mostraBachecaNascostiUtente(@RequestParam(value = "username") String username){
        // restituisce una stringa elencata i record NASCOSTI in bacheca DI UN UTENTE
        try{
            List<String> lista = dao.recuperaNascostiByDestinatario(username);
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("mostra/utente/visti")
    public ResponseEntity<String> mostraBachecaVistiUtente(@RequestParam(value = "username") String username){
        // restituisce una stringa elencata i record VISTI in bacheca DI UN UTENTE
        try{
            List<String> lista = dao.recuperaVistiByDestinatario(username);
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("mostra/utente/vistiNascosti")
    public ResponseEntity<String> mostraBachecaVistiNascostiUtente(@RequestParam(value = "username") String username){
        // restituisce una stringa elencata i record VISTI e NASCOSTI in bacheca DI UN UTENTE
        try{
            List<String> lista = dao.recuperaVistiNascostiByDestinatario(username);
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
