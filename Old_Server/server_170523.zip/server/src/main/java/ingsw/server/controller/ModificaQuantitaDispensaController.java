package ingsw.server.controller;

import ingsw.server.entityDTO.dispensaDTO.AggiungiQtaElemDispDTO;
import ingsw.server.entityDTO.dispensaDTO.RiduciQtaElemDispDTO;
import ingsw.server.factoryDAO.*;
import ingsw.server.interfacceDAO.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.xml.crypto.Data;
import java.util.List;

@RestController
@RequestMapping("controller/riduciDispensa")
public class ModificaQuantitaDispensaController {
    @Autowired
    DispensaDAO dispensaDao = DispensaFactory.getImplementation();
    @Autowired
    AvvisoDAO avvisoDao = AvvisoFactory.getImplementation();
    @Autowired
    MittenteDispensaDAO mittenteDispensaDao = MittenteDispensaFactory.getImplementation();
    @Autowired
    UtenteDAO utenteDao = UtenteFactory.getImplementation();
    @Autowired
    BachecaDAO bachecaDao = BachecaFactory.getImplementation();

    private final String SOPRA = "SOPRA";
    private final String SOTTO = "SOTTO";

    private Float recuperaQuantitaAttuale(String nome) throws DataAccessException{
        // recupero la quantita attuale dell'elemento in dispensa
        return dispensaDao.recuperaQuantitaDispensaByNome(nome);
    }

    private Float recuperaSogliaCritica(String nome) throws DataAccessException{
        // recupero la colonna Soglia critica dell'elemento
        return dispensaDao.recuperaSogliaCriticaDispensaByNome(nome);
    }

    private String confrontaDisponibilita(Float disponibilita, Float limite){
        if(disponibilita < limite)   return SOTTO;
        else return SOPRA;
    }

    private String sottoSogliaCritica(String nome) throws DataAccessException{
        // recupero la quantita attuale dell'elemento
        Float qtaAttuale = recuperaQuantitaAttuale(nome);

        // recupero la soglia critica dell'elemento
        Float sogliaCritica = recuperaSogliaCritica(nome);

        // confronto la disponibilita con la soglia critica
        // ritorno SOTTO se si trova sotto la soglia critica, SOPRA se sta al pari o sopra la soglia critica
        return confrontaDisponibilita(qtaAttuale, sogliaCritica);
    }

    private Integer recuperaIdUltimoAvvisoInserito() throws DataAccessException{
        return avvisoDao.recuperaIdUltimoAvviso();
    }

    private void generaAvvisoInBacheca(String nome) throws DataAccessException {
        // Chiedo al Database di creare l'avviso in dispensa
        avvisoDao.inserisciAvviso("SOGLIA CRITICA", "QUANTITA' DI " + nome + " AL DI SOTTO DELLA SOGLIA CRITICA");

        // chiedo al Database l'avviso appena creato
        Integer idAvviso = recuperaIdUltimoAvvisoInserito();

        // associo l'avviso all'elemento della dispensa che lo ha generato
        mittenteDispensaDao.generaAvviso(nome, Integer.valueOf(idAvviso));
    }

    private void inviaAUtente(Integer idAvviso, String username) throws DataAccessException{
        // assegno nella bacheca l'avviso all'utente
        bachecaDao.inserisciBacheca(false, false, idAvviso, username);
    }

    private void inviaAresponsabili(Integer idAvviso) throws DataAccessException{
        // invio a tutti gli ADMIN e SUPERVISOR l'avviso con codice idAvviso

        // recupero tutti gli utenti
        List<String> elencoUtenti = utenteDao.recuperaUsernameTuttiUtenti();

        // per ogni dipendente assegno l'avviso in bacheca
        for(int i=0; i<elencoUtenti.size(); i++){
            //recupero l'username dell'utente corrente
            String usernameAttuale = elencoUtenti.get(i);

            // recupero l'informazione del campo 'Ruolo' dal record dell'utente
            String ruoloUtente = utenteDao.recuperaRuoloByUsername(usernameAttuale);

            // controllo che l'utente sia un ADMIN o un SUPERVISOR
            if(ruoloUtente.equals("Admin") || ruoloUtente.equals("Supervisor")){
                // assegno l'avviso alla sua bacheca e salvo l'esito della query
                inviaAUtente(idAvviso, usernameAttuale);
            }
            // se l'utente non e' ne ADMIN ne SUPERVISOR non faccio nulla
        }
    }

    private void riduciQuantitaElem(String nome, Float qtaDaTogliere) throws DataAccessException{
        // recupero la quantita attuale dell'elemento in dispensa
        Float qtaAttuale = recuperaQuantitaAttuale(nome);

        // effettuo la sottrazione per ottenere la quantita' finale che dovra' comparire in dispensa
        Float qtaFinale = qtaAttuale - qtaDaTogliere;

        // effettuo l'update in dispensa
        dispensaDao.modificaQuantitaDispensa(nome, qtaFinale);
    }

    @PatchMapping("riduciQta")
    public ResponseEntity<String> riduciQtaElemDispensa(@RequestBody RiduciQtaElemDispDTO input){
        try{
            // effettuo la riduzione di quantita in dispensa
            riduciQuantitaElem(input.getNome(), input.getTogli());

            // controllo che la quantita sia scesa sotto la soglia critica
            String sottoSoglia = sottoSogliaCritica(input.getNome());

            // termino con SUCCESSO se non e' scesa sotto la soglia critica
            if(sottoSoglia.equals(SOPRA))
                return ResponseEntity.ok().body("Quantita ridotta con successo");

            // mentre se e' scesa sotto la soglia critica
            else{
                // genero l'avviso da inserire sulla bacheca di Admin e Supervisor
                generaAvvisoInBacheca(input.getNome());

                // recupero l'idAvviso dell'avviso appena generato
                Integer idAvviso = recuperaIdUltimoAvvisoInserito();

                // assegno l'avviso ad admin e supervisor
                inviaAresponsabili(idAvviso);
                return ResponseEntity.ok().body("Avviso in bacheca creato e quantita ridotta con successo");
            }

        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("aggiungiQta")
    public ResponseEntity<String> aggiungiQuantitaElem(@RequestBody AggiungiQtaElemDispDTO input){
        try{
            // recupero la quantita attuale dell'elemento in dispensa
            Float qtaAttuale = recuperaQuantitaAttuale(input.getNome());

            // effettuo la somma per ottenere la quantita' finale che dovra' comparire in dispensa
            Float qtaFinale = qtaAttuale + input.getAggiungi();

            // effettuo l'update in dispensa
            dispensaDao.modificaQuantitaDispensa(input.getNome(), qtaFinale);
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
