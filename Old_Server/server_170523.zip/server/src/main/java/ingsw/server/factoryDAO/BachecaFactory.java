package ingsw.server.factoryDAO;

import ingsw.server.factoryLogic.LeggiModelXML;
import ingsw.server.interfacceDAO.BachecaDAO;
import ingsw.server.postgreDAO.BachecaPostgreImpl;

public class BachecaFactory {
    public static BachecaDAO getImplementation(){
        String storage = LeggiModelXML.getStorage("Bacheca");
        if(storage.equals("PostgreSQL"))
            return new BachecaPostgreImpl();
        else return null;
    }
}
