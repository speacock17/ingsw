package ingsw.server.factoryDAO;

import ingsw.server.factoryLogic.LeggiModelXML;
import ingsw.server.interfacceDAO.OrdineDAO;
import ingsw.server.postgreDAO.OrdinePostgreImpl;

public class OrdineFactory {
    public static OrdineDAO getImplementation(){
        String storage = LeggiModelXML.getStorage("Ordine");
        if(storage.equals("PostgreSQL"))
            return new OrdinePostgreImpl();
        else return null;
    }
}
