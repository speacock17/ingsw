package ingsw.server.controller;

import ingsw.server.entityDTO.dispensaDTO.RiduciQtaElemDispDTO;
import ingsw.server.factoryDAO.DispensaFactory;
import ingsw.server.factoryDAO.IngredientiFactory;
import ingsw.server.interfacceDAO.DispensaDAO;
import ingsw.server.interfacceDAO.IngredientiDAO;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;

import java.util.List;

public class RiduciQuantitaIngredientiController {

    IngredientiDAO ingredientiDao = IngredientiFactory.getImplementation();
    DispensaDAO dispensaDao = DispensaFactory.getImplementation();

    private final String SUCCESSO = "SUCCESSO";
    private final String FALLIMENTO = "FALLIMENTO";
    private final String INSUFFICIENTE = "INSUFFICIENTE";
    private final String DISPONIBILIE = "DISPONIBILE";

    private String verificaDisponibilita(Float disponibilita, Float riduzione){
        if(riduzione <= disponibilita)   return DISPONIBILIE;
        else return INSUFFICIENTE;
    }

    public String riduciQuantitaIngredienti(String elemMenu){
        // riduci la quantita degli ingredienti dell' elemento del menu
        try{
            List<String> lista = ingredientiDao.recuperaElemDispensaIngredientiByElemMenu(elemMenu);

            // finche ci sono ingredienti da scorrere
            for(int i=0; i<lista.size(); i++){
                // recupero il nome dell'ingrediente corrente
                String elemDispensa = lista.get(i);

                // recupero la quantita necessaria dell'ingrediente
                Float quantitaNecessaria = ingredientiDao.recuperaQuantitaIngrediente(elemMenu, elemDispensa);

                // recupero la quantita a disposizione dell' elemento in dispensa
                Float quantitaDisponibile = dispensaDao.recuperaQuantitaDispensaByNome(elemDispensa);

                // controllo che ci sia abbastanza quantita in dispensa
                String dispo = verificaDisponibilita(quantitaDisponibile, quantitaNecessaria);

                if(dispo.equals(INSUFFICIENTE))   return INSUFFICIENTE;

                if(dispo.equals(DISPONIBILIE)){
                    RiduciQtaElemDispDTO riduci = new RiduciQtaElemDispDTO(elemDispensa, quantitaNecessaria);
                    ModificaQuantitaDispensaController riduciController = new ModificaQuantitaDispensaController();

                    ResponseEntity<String> risultato = riduciController.riduciQtaElemDispensa(riduci);
                    if(risultato.getStatusCode().is2xxSuccessful())     continue;
                    else return FALLIMENTO;
                }
            }
            // se la computazione dello scorrimento del resultSet termina, vuol dire che e' andato tutto bene
            return SUCCESSO;

        } catch (DataAccessException e){
            return FALLIMENTO;
        }
    }
}
