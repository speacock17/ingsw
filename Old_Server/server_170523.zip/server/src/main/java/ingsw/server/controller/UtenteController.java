package ingsw.server.controller;

import ingsw.server.entityDTO.utenteDTO.*;
import ingsw.server.factoryDAO.UtenteFactory;
import ingsw.server.interfacceDAO.UtenteDAO;
import ingsw.server.responseBodyBuilder.SendListaStringhe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController         //serve per poter usare le notazioni e mappare i metodi
@RequestMapping("controller/utente")        // definisce il path per accedere tramite http ai metodi di questo controller
public class UtenteController{
    @Autowired
    UtenteDAO dao = UtenteFactory.getImplementation();

    @PostMapping("registra")
    public ResponseEntity<String> insertUtente(@RequestParam(value = "ruolo") String ruolo,
                                               @RequestBody RegistraFormDTO input){
        // effettua la registrazione nel database di un nuovo utente, dunque un utente con tipoDiRuolo ricevuto come parametro
        try {
            dao.inserisciUtente(
                        input.getNome(),
                        input.getCognome(),
                        input.getUsername(),
                        input.getPassword(),
                        ruolo);
            return ResponseEntity.ok().body("Registrazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/nome")
    public ResponseEntity<String> updateNomeUtente(@RequestBody ModNomeUtenteDTO input){
        try {
            dao.modificaNomeUtente(input.getUsername(), input.getNome());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/cognome")
    public ResponseEntity<String> updateCognomeUtente(@RequestBody ModCognomeUtenteDTO input){
        try {
            dao.modificaCognomeUtente(input.getUsername(), input.getCognome());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/username")
    public ResponseEntity<String> updateUsernameUtente(@RequestBody ModUsernameUtenteDTO input){
        try {
            dao.modificaUsernameUtente(input.getUsername(), input.getNewUsername());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/password")
    public ResponseEntity<String> updatePasswordUtente(@RequestBody ModPasswordUtenteDTO input){
        try {
            dao.modificaPasswordUtente(input.getUsername(), input.getPassword());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/ruolo")
    public ResponseEntity<String> updateRuoloUtente(@RequestBody ModRuoloUtenteDTO input){
        try {
            dao.modificaRuoloUtente(input.getUsername(), input.getRuolo());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/user")
    public ResponseEntity<String> deleteUtenteByUsername(@RequestParam (value = "username") String username){
        try {
            dao.eliminaUtenteByUsername(username);
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/ruolo/{nomeRuolo}")
    public ResponseEntity<String> deleteUtentiByRuolo(@PathVariable (value = "nomeRuolo") String ruolo){
        try {
            dao.eliminaUtentiByRuolo(ruolo);
        return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/tuttiUtenti")
    public ResponseEntity<String> deleteTuttiUtenti(){
        try {
            dao.eliminaTuttiUtenti();
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/user")
    public ResponseEntity<String> recuperaUtentiNoPassword(@RequestParam(value = "username") String username){
        // restituisce una stringa elencata con i valori nome, cognome, username e ruolo di quell' utente
        try{
            String query = dao.recuperaUtenteNoPassword(username);
            return ResponseEntity.ok().body(query);
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/ruolo/{nomeRuolo}")
    public ResponseEntity<String> recuperaUtentiByRuolo(@PathVariable(value = "nomeRuolo") String ruolo){
        //restituisce un arraylist con i valori nome, cognome, username e ruolo di tutti gli utenti di un certo ruolo
        try {
            List<String> lista = dao.recuperaUtentiByRuolo(ruolo);
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/tuttiUtenti")
    public ResponseEntity<String> recuperaTuttiUtenti(){
        // restituisce una stringa elencata con i valori nome, cognome, username, PASSWORD e ruolo di tutti gli utenti di un certo ruolo
        try {
            List<String> lista = dao.recuperaTuttiUtenti();
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
