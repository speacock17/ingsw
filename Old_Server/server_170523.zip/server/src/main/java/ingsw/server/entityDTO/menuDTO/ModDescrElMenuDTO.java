package ingsw.server.entityDTO.menuDTO;

public class ModDescrElMenuDTO {
    private String nome;
    private String descrizione;

    public String getNome() {
        return nome;
    }

    public String getDescrizione() {
        return descrizione;
    }
}
