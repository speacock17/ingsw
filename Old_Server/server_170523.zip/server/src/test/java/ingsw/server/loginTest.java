package ingsw.server;

import ingsw.server.factoryDAO.UtenteFactory;
import ingsw.server.interfacceDAO.UtenteDAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataAccessException;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class loginTest {
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    UtenteDAO utenteDao = UtenteFactory.getImplementation();

    final String url = "http://localhost:8080/controller/utente/login";
    final String username = "superuser";

    private String generaBody(String username, String password){
        return "{\"username\":\"" + username +
                "\",\"password\":\"" + password + "\"}";
    }

    private MockHttpServletRequestBuilder generaRichiesta(String url, String body){
        return MockMvcRequestBuilders.get(url)
                .contentType(MediaType.APPLICATION_JSON)
                .content(body);
    }

    @BeforeEach
    void init(){
        try {
            utenteDao.inserisciUtente("superuser", "superuser", username , "superuser", "Admin");
        } catch (DataAccessException e){
            System.out.println("Errore nel metodo init: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("Username non esiste, password valida - login fallito")
    void usernameNonEsistePasswordValidaTest(){
        //ARRANGE
        String body = generaBody("nonEsisto", "password");

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        //ACT e ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Utente non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Username esiste, password vuota - login fallito")
    void usernameEsistePasswordVuotaTest(){
        //ARRANGE
        String body = generaBody(username, "");

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        //ACT e ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Username vuoto, password valida - login fallito")
    void usernameVuotoPasswordValidaTest(){
        //ARRANGE
        String body = generaBody("", "password");

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        //ACT e ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Utente non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Username esiste, password nulla- login fallito")
    void usernameEsistePasswordNullaTest(){
        //ARRANGE
        String body = "{\"username\":\"" + username + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        //ACT e ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Username nullo, password valida - login fallito")
    void usernameNulloPasswordValidaTest(){
        //ARRANGE
        String body = "{\"password\":\"" + "password" + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        //ACT e ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Utente non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Username esiste, password diversa - login fallito")
    void usernameEsistePasswordDiversaTest(){
        //ARRANGE
        String body = generaBody(username, "passwordDiversa");

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        //ACT e ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Failure: Password diverse"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Username esiste, password corretta, primo accesso ancora non effettuato (FALSE) - login EFFETTUATO")
    void usernameEsistePasswordUgualePrimoAccessoTest(){
        //ARRANGE
        String body = generaBody(username, username);

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        //ACT e ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isOk())
                    .andExpect(MockMvcResultMatchers.content().string("Successo: Primo accesso effettuato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Username esiste, password corretta, primo accesso gia effettuato (TRUE) - login EFFETTUATO")
    void usernameEsistePasswordUgualePrimoAccessoGiaEffettuatoTest(){
        //ARRANGE
        try{
            utenteDao.modificaPrimoAccessoUtente(username, true);
        } catch (DataAccessException e){
            System.out.println(e.getMessage());
        }

        String body = generaBody(username, username);

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        //ACT e ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isOk())
                    .andExpect(MockMvcResultMatchers.content().string("Successo: Login effettuato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @AfterEach
    void done(){
        try {
            utenteDao.eliminaUtenteByUsername(username);
        }catch (DataAccessException e){
            System.out.println("Errore nel metodo done: " + e.getMessage());
        }
    }
}
