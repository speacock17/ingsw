package ingsw.server;

import ingsw.server.factoryDAO.AvvisoFactory;
import ingsw.server.factoryDAO.UtenteFactory;
import ingsw.server.interfacceDAO.AvvisoDAO;
import ingsw.server.interfacceDAO.UtenteDAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataAccessException;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class scriveAvvisoTest {
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    UtenteDAO utenteDao = UtenteFactory.getImplementation();
    @Autowired
    AvvisoDAO avvisoDao = AvvisoFactory.getImplementation();

    final String url = "http://localhost:8080/controller/avvisiUtente/scriveAvviso";
    final String username = "superuser";
    final String oggetto = "oggetto di prova";
    final String testo = "testo di prova";
    Integer idAvviso;

    private void eliminaAvviso(){
        try{
            idAvviso = avvisoDao.recuperaIdUltimoAvviso();
            avvisoDao.eliminaAvvisoById(idAvviso);
        } catch (DataAccessException e){
            System.out.println("Errore nel metodo eliminaAvviso: " + e.getMessage());
        }
    }

    private String generaBody(String username, String oggetto, String testo){
        return "{\"username\":\"" + username + "\",\"oggetto\": \""
                + oggetto + "\", \"testo\":\"" + testo + "\"}";
    }

    private MockHttpServletRequestBuilder generaRichiesta(String url, String body){
        return MockMvcRequestBuilders.post(url)
                .contentType(MediaType.APPLICATION_JSON)
                .content(body);
    }

    @BeforeEach
    void init(){
        try {
            utenteDao.inserisciUtente("superuser", "superuser", username , "superuser", "Admin");
        } catch (DataAccessException e){
            System.out.println("Errore nel metodo init: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("L'utente esiste e crea un avviso valido")
    void usernameEsisteOggettoValidoTestoValidoTest(){
        // ARRANGE
        String body = generaBody(username, oggetto, testo);

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isOk());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        eliminaAvviso();
    }

    @Test
    @DisplayName("L'utente non esiste e crea un avviso valido")
    void usernameNonEsisteOggettoValidoTestoValido(){
        // ARRANGE
        String body = generaBody("nonEsisto", oggetto, testo);

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Utente non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("L'utente vuoto e crea un avviso valido")
    void usernameVuotoOggettoValidoTestoValidoTest(){
        // ARRANGE
        String body = generaBody("", oggetto, testo);

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Utente non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }


    @Test
    @DisplayName("L'utente esiste e crea un avviso NON valido - OGGETTO VUOTO")
    void usernameEsisteOggettoNonValidoTestoValidoTest(){
        // ARRANGE
        String body = generaBody(username, "", testo);

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("L'utente esiste e crea un avviso NON valido - TESTO VUOTO")
    void usernameEsisteOggettoValidoTestoNonValidoTest(){
        // ARRANGE
        String body = generaBody(username, oggetto, "");

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("L'utente non valido e crea un avviso valido")
    void usernameNulloOggettoValidoTestoValidoTest(){
        // ARRANGE
        String body = "{\"oggetto\": \"" + oggetto + "\", \"testo\":\"" + testo + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Utente non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("L'utente esiste e crea un avviso NON valido - OGGETTO NULL")
    void usernameEsisteOggettoNulloTestoValidoTest(){
        // ARRANGE
        String body = "{\"username\":\"" + username + "\", \"testo\":\"" + testo + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("L'utente esiste e crea un avviso NON valido - TESTO NULL")
    void usernameEsisteOggettoValidoTestoNulloTest(){
        // ARRANGE
        String body = "{\"username\":\"" + username + "\",\"oggetto\": \"" + oggetto + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @AfterEach
    void done(){
        try {
            utenteDao.eliminaUtenteByUsername(username);
        }catch (DataAccessException e){
            System.out.println("Errore nel metodo done: " + e.getMessage());
        }
    }
}
