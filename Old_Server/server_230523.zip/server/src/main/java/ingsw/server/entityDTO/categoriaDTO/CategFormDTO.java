package ingsw.server.entityDTO.categoriaDTO;

public class CategFormDTO {
    private String nome;
    private Integer postoMenu;

    public String getNome() {
        return nome;
    }

    public Integer getPostoMenu() {
        return postoMenu;
    }
}
