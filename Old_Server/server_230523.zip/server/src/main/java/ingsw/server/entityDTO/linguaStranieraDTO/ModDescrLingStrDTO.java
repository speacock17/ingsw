package ingsw.server.entityDTO.linguaStranieraDTO;

public class ModDescrLingStrDTO {
    private String elementoMenu;
    private String descrizione;

    public String getElementoMenu() {
        return elementoMenu;
    }

    public String getDescrizione() {
        return descrizione;
    }
}
