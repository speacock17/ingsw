package ingsw.server.entityDTO.dispensaDTO;

public class ModSogliaCritElemDispDTO {
    private String nome;
    private Float sogliaCritica;

    public String getNome() {
        return nome;
    }

    public Float getSogliaCritica() {
        return sogliaCritica;
    }
}
