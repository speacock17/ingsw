package ingsw.server.controller;

import ingsw.server.entityDTO.dispensaDTO.*;
import ingsw.server.interfacceDAO.DispensaDAO;
import ingsw.server.responseBodyBuilder.SendListaStringhe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("controller/dispensa")
public class DispensaController{
    private final DispensaDAO dao;

    @Autowired
    public DispensaController(DispensaDAO dao) {
        this.dao = dao;
    }

    @PostMapping("registra")
    public ResponseEntity<String> insertElemDispensa(@RequestBody RegistraDispensaDTO input){
        // effettua la registrazione nel database di un nuovo elemento della dispensa
        try{
            dao.inserisciDispensa(
                        input.getNome(),
                        input.getDescrizione(),
                        input.getCostoAcq(),
                        input.getUnitaDiMisura(),
                        input.getQuantita(),
                        input.getSogliaCritica()
                );
            return ResponseEntity.ok().body("Registrazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/nome")
    public ResponseEntity<String> updateNomeElemDispensa(@RequestBody ModNomeElemDispDTO input){
        try{
            dao.modificaNomeDispensa(input.getNome(), input.getNewNome());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/descrizione")
    public ResponseEntity<String> updateDescrizioneElemDispensa(@RequestBody ModDescrElemDispDTO input){
        try{
           dao.modificaDescrizioneDispensa(input.getNome(), input.getDescrizione());
           return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/costoAcq")
    public ResponseEntity<String> updateCostoAcqElemDispensa(@RequestBody ModCostoAcqElemDispDTO input){
        try{
            dao.modificaCostoAcquistoDispensa(input.getNome(), input.getCostoAcq());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/unitaDiMisura")
    public ResponseEntity<String> updateUdMElemDispensa(@RequestBody ModUdMElemDispDTO input){
        try{
            dao.modificaUnitaDiMisuraDispensa(input.getNome(), input.getUnitaDiMisura());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/quantita")
    public ResponseEntity<String> updateQuantitaElemDispensa(@RequestBody ModQtaElemDispDTO input){
        try{
            dao.modificaQuantitaDispensa(input.getNome(), input.getQuantita());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/sogliaCritica")
    public ResponseEntity<String> updateSogliaCriticaElemDispensa(@RequestBody ModSogliaCritElemDispDTO input){
        try{
            dao.modificaSogliaCriticaDispensa(input.getNome(), input.getSogliaCritica());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/elemDispensa")
    public ResponseEntity<String> deleteDispensaByNome(@RequestBody NomeElemDispDTO input){
        try{
            dao.eliminaDispensaByNome(input.getNome());
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/Dispensa")
    public ResponseEntity<String> deleteDispensa(){
        try{
            dao.eliminaTuttaDispensa();
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/elemDispensa")
    public ResponseEntity<String> recuperaDispensaByNome(@RequestBody NomeElemDispDTO input){
        // restituisce una stringa elencata con i valori:
        // nome, descrizione, costo acquisto, unita di misura, quantita, soglia critica
        try{
            String query = dao.recuperaDispensaByNome(input.getNome());
            return ResponseEntity.ok().body(query);
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/dispensa")
    public ResponseEntity<String> recuperaTuttaDispensa(){
        // restituisce una stringa elencata con tutti i dettagli di TUTTI gli elementi della dispensa
        try{
            List<String> lista = dao.recuperaTuttaDispensa();
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
