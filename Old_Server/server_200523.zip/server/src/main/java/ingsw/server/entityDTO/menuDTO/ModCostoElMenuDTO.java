package ingsw.server.entityDTO.menuDTO;

public class ModCostoElMenuDTO {
    private String nome;
    private Float costo;

    public String getNome() {
        return nome;
    }

    public Float getCosto() {
        return costo;
    }
}
