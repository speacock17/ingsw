package ingsw.server.entityDTO.linguaStranieraDTO;

public class ModDescrLingStrDTO {
    private String elementoMenu;
    private String descrizioneProdotto;

    public String getElementoMenu() {
        return elementoMenu;
    }

    public String getDescrizioneProdotto() {
        return descrizioneProdotto;
    }
}
