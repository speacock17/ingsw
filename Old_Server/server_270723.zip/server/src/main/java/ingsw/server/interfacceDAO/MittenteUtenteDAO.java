package ingsw.server.interfacceDAO;

public interface MittenteUtenteDAO {
    /*
        Create table MittenteU(
    Mittente varchar(50) NOT NULL,
    IdAvviso integer NOT NULL,
     */
    public void scriveAvviso(String username, Integer idAvviso);
}
