package ingsw.server.entityDTO.dispensaDTO;

public class ModDescrElemDispDTO {
    private String nome;
    private String descrizione;

    public String getNome() {
        return nome;
    }

    public String getDescrizione() {
        return descrizione;
    }
}
