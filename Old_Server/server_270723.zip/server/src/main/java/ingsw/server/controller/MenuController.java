package ingsw.server.controller;

import ingsw.server.interfacceDAO.MenuDAO;
import ingsw.server.entityDTO.menuDTO.*;
import ingsw.server.responseBodyBuilder.SendListaStringhe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController         //serve per poter usare le notazioni e mappare i metodi
@RequestMapping("controller/menu")      // definisce il path per accedere tramite http ai metodi di questo controller
public class MenuController{
    private final MenuDAO dao;          //ottengo un oggetto che implementa la dao

    @Autowired
    public MenuController(MenuDAO dao) {
        this.dao = dao;
    }

    @PostMapping("registra")
    public ResponseEntity<String> inserisciMenu(@RequestBody ElemMenuFormDTO input){
        // effettua la registrazione nel database di un nuovo elemento del menu
        try{
            dao.inserisciMenu(
                    input.getNome(),
                    input.getDescrizione(),
                    input.getCosto(),
                    input.getAllergeni(),
                    input.getCategoria()
            );
            return ResponseEntity.ok().body("Registrazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/nome")
    public ResponseEntity<String> modificaNomeMenu(@RequestBody ModNomeElMenuDTO input){
        try{
            dao.modificaNomeMenu(input.getNome(), input.getNewName());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/descrizione")
    public ResponseEntity<String> modificaDescrizioneMenu(@RequestBody ModDescrElMenuDTO input){
        try{
            dao.modificaDescrizioneMenu(input.getNome(), input.getDescrizione());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/costo")
    public ResponseEntity<String> modificaCostoMenu(@RequestBody ModCostoElMenuDTO input){
        try{
            dao.modificaCostoMenu(input.getNome(), input.getCosto());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/allergeni")
    public ResponseEntity<String> modificaAllergeniMenu(@RequestBody ModAllergeniElMenuDTO input){
        try{
            dao.modificaAllergeniMenu(input.getNome(), input.getAllergeni());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/categoria")
    public ResponseEntity<String> modificaCategoriaMenu(@RequestBody ModCategElMenuDTO input){
        try{
            dao.modificaCategoriaMenu(input.getNome(), input.getCategoria());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/postoCategoria")
    public ResponseEntity<String> modificaPostoCategoriaMenu(@RequestBody ModPostoCategElMenuDTO input){
        try{
            dao.modificaPostoCategoriaMenu(input.getNome(), input.getPostoCategoria());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/elementoMenu")
    public ResponseEntity<String> eliminaMenuByNome(@RequestBody NomeElemMenuDTO input){
        try{
           dao.eliminaMenuByNome(input.getNome());
           return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/tuttoMenu")
    public ResponseEntity<String> eliminaTuttoMenu(){
        try{
            dao.eliminaTuttoMenu();
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("recupera/elemMenu")
    public ResponseEntity<String> recuperaMenuByNome(@RequestBody NomeElemMenuDTO input){
        // restituisce una stringa elencata con i valori:
        // nome, descrizione, costo, allergeni, categoria, posto categoria
        try{
            String query = dao.recuperaMenuByNome(input.getNome());
            return ResponseEntity.ok().body(query);
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/tuttoMenu")
    public ResponseEntity<String> recuperaTuttoMenu(){
        // restituisce tutti i valori di TUTTI gli elementi del menu
        try{
            List<String> lista = dao.recuperaTuttoMenu();
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("recupera/menuByCategoria")
    public ResponseEntity<String> recuperaMenuByCategoria(@RequestBody NomeCategMenuDTO input){
        // restituisce tutti i valori di TUTTI gli elementi di una CATEGORIA del menu
        try{
            List<String> lista = dao.recuperaMenuByCategoria(input.getCategoria());
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
