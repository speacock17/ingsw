package ingsw.server.entityDTO.linguaStranieraDTO;

public class NomeElemMenuDTO {
    private String elementoMenu;

    public String getElementoMenu() {
        return elementoMenu;
    }
}
