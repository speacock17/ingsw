package ingsw.server.interfacceDAO;


import java.util.List;

public interface IngredientiDAO {
    /*
        Create table Ingredienti(
        Quantita float NOT NULL,
        UdM UnitaDiMisura NOT NULL,     //DEVE ESSERE AUTOCOMPILATA
        ElementoMenu varchar(100) NOT NULL,
        ElementoDispensa varchar(50) NOT NULL,
    */
    public void inserisciIngredienti(Float quantita,
                                     String UdM,
                                     String elemMenu,
                                     String elemDispensa);
    public void modificaQuantita(String elemMenu, String elemDispensa, Float quantita);
    public void eliminaIngrediente(String elemMenu, String elemDispensa);
    public void eliminaIngredientiElemMenu(String elemMenu);
    public void eliminaTuttiIngredienti();
    public String recuperaIngrediente(String elemMenu, String elemDispensa);
    public Float recuperaQuantitaIngrediente(String elemMenu, String elemDispensa);
    public String recuperaUdMIngrediente(String elemMenu, String elemDispensa);
    public List<String> recuperaIngredientiByElemMenu(String elemMenu);
    public List<String> recuperaIngredientiMancanti(String elemMenu);
    public List<String> recuperaElemDispensaIngredientiByElemMenu(String elemMenu);
    public List<String> recuperaTuttiIngredienti();
}
