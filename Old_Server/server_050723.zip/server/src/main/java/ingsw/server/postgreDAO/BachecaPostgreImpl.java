package ingsw.server.postgreDAO;

import ingsw.server.interfacceDAO.BachecaDAO;
import ingsw.server.springDataMapper.StringDataMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class BachecaPostgreImpl implements BachecaDAO {
    final JdbcTemplate jdbcTemplate;

    @Autowired
    public BachecaPostgreImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /*
        Create table Bacheca(
    Visualizzato boolean NOT NULL,
    Nascosto boolean NOT NULL,
    IdAvviso integer NOT NULL,
    Destinatario varchar(50) NOT NULL,
     */

    @Override
    public void inserisciBacheca(Boolean visualizzato, Boolean nascosto, Integer idAvviso, String destinatario) {
        jdbcTemplate.update("INSERT INTO BACHECA VALUES (?, ?, ?, ?)",
                visualizzato, nascosto, idAvviso, destinatario);
    }

    @Override
    public void modificaVisualizzato(Boolean visualizzato, Integer idAvviso, String destinatario) {
        jdbcTemplate.update("UPDATE BACHECA SET Visualizzato = ? WHERE IdAvviso = ? AND Destinatario = ?",
                visualizzato, idAvviso, destinatario);
    }

    @Override
    public void modificaNascosto(Boolean nascosto, Integer idAvviso, String destinatario) {
        jdbcTemplate.update("UPDATE BACHECA SET Nascosto = ? WHERE IdAvviso = ? AND Destinatario = ?",
                nascosto, idAvviso, destinatario);
    }

    @Override
    public void eliminaById(Integer idAvviso, String username) {
        jdbcTemplate.update("DELETE FROM BACHECA WHERE IdAvviso = ? AND Destinatario = ?",
                idAvviso, username);
    }

    @Override
    public void eliminaBachecaByUsername(String destinatario) {
        jdbcTemplate.update("DELETE FROM BACHECA WHERE Destinatario = ?", destinatario);
    }

    @Override
    public void eliminaTuttaBacheca() {
        jdbcTemplate.update("DELETE FROM BACHECA");
    }

    @Override
    public List<String> recuperaBachecaByDestinatario(String destinatario) {
        return jdbcTemplate.query("SELECT * FROM BACHECA WHERE Destinatario = ?",
                new StringDataMapper());
    }

    @Override
    public List<String> recuperaVisibili(String destinatario) {
        return jdbcTemplate.query("SELECT * FROM BACHECA WHERE Nascosto = false AND Destinatario = ?",
                new StringDataMapper(), destinatario);
    }

    @Override
    public List<String> recuperaNascosti(String destinatario) {
        return jdbcTemplate.query("SELECT * FROM BACHECA WHERE Nascosto = true AND Destinatario = ?",
                new StringDataMapper(), destinatario);
    }

    @Override
    public List<String> recuperaVisti(String destinatario) {
        return jdbcTemplate.query("SELECT * FROM BACHECA WHERE Visualizzato = true AND Nascosto = false AND Destinatario = ?",
                new StringDataMapper(), destinatario);
    }

    @Override
    public List<String> recuperaVistiNascosti(String destinatario) {
        return jdbcTemplate.query("SELECT * FROM BACHECA WHERE Visualizzato = true AND Nascosto = true AND Destinatario = ?",
                new StringDataMapper(), destinatario);
    }

    @Override
    public List<String> recuperaTuttaBacheca() {
        return jdbcTemplate.query("SELECT * FROM BACHECA", new StringDataMapper());
    }
}
