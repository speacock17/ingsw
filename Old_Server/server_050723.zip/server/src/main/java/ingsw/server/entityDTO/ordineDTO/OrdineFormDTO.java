package ingsw.server.entityDTO.ordineDTO;

public class OrdineFormDTO {
    private Integer numeroTavolo;
    private String elementoMenu;

    public Integer getNumeroTavolo() {
        return numeroTavolo;
    }

    public String getElementoMenu() {
        return elementoMenu;
    }
}
