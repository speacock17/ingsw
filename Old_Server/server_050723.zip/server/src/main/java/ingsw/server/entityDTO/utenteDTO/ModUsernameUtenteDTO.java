package ingsw.server.entityDTO.utenteDTO;

public class ModUsernameUtenteDTO {
    String username;
    String newUsername;

    public String getUsername() {
        return username;
    }

    public String getNewUsername() {
        return newUsername;
    }
}
