package ingsw.server.entityDTO.menuDTO;

public class ModPostoCategElMenuDTO {
    private String nome;
    private Integer postoCategoria;

    public String getNome() {
        return nome;
    }

    public Integer getPostoCategoria() {
        return postoCategoria;
    }
}
