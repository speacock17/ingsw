package ingsw.server.entityDTO.menuDTO;

public class NomeCategMenuDTO {
    private String categoria;

    public String getCategoria() {
        return categoria;
    }
}
