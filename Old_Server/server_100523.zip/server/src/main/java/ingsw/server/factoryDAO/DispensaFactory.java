package ingsw.server.factoryDAO;

import ingsw.server.factoryLogic.LeggiModelXML;
import ingsw.server.interfacceDAO.DispensaDAO;
import ingsw.server.postgreDAO.DispensaPostgreImpl;

public class DispensaFactory {
    public static DispensaDAO getImplementation(){
        String storage = LeggiModelXML.getStorage("Dispensa");
        if(storage.equals("PostgreSQL"))
            return new DispensaPostgreImpl();
        else return null;
    }
}
