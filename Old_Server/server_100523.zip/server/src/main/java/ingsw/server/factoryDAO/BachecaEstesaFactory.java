package ingsw.server.factoryDAO;

import ingsw.server.factoryLogic.LeggiModelXML;
import ingsw.server.interfacceDAO.BachecaEstesaDAO;
import ingsw.server.postgreDAO.BachecaEstesaDispensaPostgreImpl;
import ingsw.server.postgreDAO.BachecaEstesaUtentePostgreImpl;

public class BachecaEstesaFactory {
    public static BachecaEstesaDAO getImplementation(String autore){
        if(autore.equals("DISPENSA")){
            String storage = LeggiModelXML.getStorage("BachecaEstesaDispensa");
            if(storage.equals("PostgreSQL"))
                return new BachecaEstesaDispensaPostgreImpl();
            else return null;
        }

        else if(autore.equals("UTENTE")){
            String storage = LeggiModelXML.getStorage("BachecaEstesaUtente");
            if(storage.equals("PostgreSQL"))
                return new BachecaEstesaUtentePostgreImpl();
            else return null;
        }
        else return null;
    }
}
