package ingsw.server.controller;

import ingsw.server.entityDTO.linguaStranieraDTO.*;
import ingsw.server.factoryDAO.LinguaStranieraFactory;
import ingsw.server.interfacceDAO.LinguaStranieraDAO;
import ingsw.server.responseBodyBuilder.SendListaStringhe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("controller/linguaStraniera")
public class LinguaStranieraController{
    @Autowired
    LinguaStranieraDAO dao = LinguaStranieraFactory.getImplementation();

    @PostMapping("registra")
    public ResponseEntity<String> insertElemMenuLingStr(@RequestBody LinguaStranFormDTO input){
        // effettua la registrazione nel database di un nuovo elemento del menu in LINGUA STRANIERA
        try{
            dao.inserisciLinguaStraniera(
                    input.getLingua(),
                    input.getNomeProdotto(),
                    input.getDescrizioneProdotto(),
                    input.getElementoMenu()
            );
            return ResponseEntity.ok().body("Registrazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/lingua")
    public ResponseEntity<String> updateLinguaLingStr(@RequestBody ModLinguaLingStrDTO input){
        // modifica la lingua di un elemento descritto in LINGUA STRANIERA
        try{
            dao.modificaLinguaElemLingStr(
                    input.getElementoMenu(),
                    input.getLingua()
            );
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/nome")
    public ResponseEntity<String> updateNomeLingStr(@RequestBody ModNomeProdLingStrDTO input){
        // modifica il nome di un elemento descritto in LINGUA STRANIERA
        try{
            dao.modificaNomeLingStr(
                    input.getElementoMenu(),
                    input.getNomeProdotto()
            );
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/descrizione")
    public ResponseEntity<String> updateDescrLingStr(@RequestBody ModDescrLingStrDTO input){
        // modifica la descrizione di un elemento descritto in LINGUA STRANIERA
        try{
            dao.modificaDescrElemMenu(
                    input.getElementoMenu(),
                    input.getDescrizione()
            );
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/elemento")
    public ResponseEntity<String> deleteElemLingStr(@RequestBody NomeElemMenuDTO input){
        // elimina un elemento descritto in LINGUA STRANIERA
        try{
            dao.eliminaElemMenu(input.getElementoMenu());
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/tuttaLinguaStraniera")
    public ResponseEntity<String> deleteTuttaLingStr(){
        // elimina tutti gli elementi in LINGUA STRANIERA
        try{
            dao.eliminaTuttoMenu();
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/elemento")
    public ResponseEntity<String> recuperaElementoLingStr(@RequestBody NomeElemMenuDTO input){
        // recupera un SOLO elemento in LINGUA STRANIERA
        try{
            String query = dao.recuperaElemLinguaStr(input.getElementoMenu());
            return ResponseEntity.ok().body(query);
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/tuttaLinguaStraniera")
    public ResponseEntity<String> recuperaTuttaLingStr(){
        // recupera tutti gli elementi in LINGUA STRANIERA
        try{
            List<String> lista = dao.recuperaTuttaLinguaStraniera();
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
