package ingsw.server.factoryDAO;

import ingsw.server.factoryLogic.LeggiModelXML;
import ingsw.server.interfacceDAO.MittenteDispensaDAO;
import ingsw.server.postgreDAO.MittenteDispensaPostgreImpl;

public class MittenteDispensaFactory {
    public static MittenteDispensaDAO getImplementation(){
        String storage = LeggiModelXML.getStorage("MittenteDispensa");
        if(storage.equals("PostgreSQL"))
            return new MittenteDispensaPostgreImpl();
        else return null;
    }
}
