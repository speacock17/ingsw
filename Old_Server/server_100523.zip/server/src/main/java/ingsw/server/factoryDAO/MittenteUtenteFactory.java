package ingsw.server.factoryDAO;

import ingsw.server.factoryLogic.LeggiModelXML;
import ingsw.server.interfacceDAO.MittenteUtenteDAO;
import ingsw.server.postgreDAO.MittenteUtentePostgreImpl;

public class MittenteUtenteFactory {
    public static MittenteUtenteDAO getImplementation(){
        String storage = LeggiModelXML.getStorage("MittenteUtente");
        if(storage.equals("PostgreSQL"))
            return new MittenteUtentePostgreImpl();
        else return null;
    }
}
