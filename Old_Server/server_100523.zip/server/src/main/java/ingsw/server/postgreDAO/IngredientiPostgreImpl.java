package ingsw.server.postgreDAO;

import ingsw.server.interfacceDAO.IngredientiDAO;
import ingsw.server.springDataMapper.StringDataMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class IngredientiPostgreImpl implements IngredientiDAO {
    @Autowired
    JdbcTemplate jdbcTemplate;
    /*
        Create table Ingredienti(
        Quantita float NOT NULL,
        UdM UnitaDiMisura NOT NULL,     //DEVE ESSERE AUTOCOMPILATA
        ElementoMenu varchar(100) NOT NULL,
        ElementoDispensa varchar(50) NOT NULL,
    */

    @Override
    public void inserisciIngredienti(Float quantita, String UdM, String elemMenu, String elemDispensa) {
        jdbcTemplate.update("INSERT INTO INGREDIENTI VALUES (?,?,?,?)",
                quantita, UdM, elemMenu, elemDispensa);
    }

    @Override
    public void modificaQuantita(String elemMenu, String elemDispensa, Float quantita) {
        jdbcTemplate.update("UPDATE INGREDIENTI SET Quantita = ? WHERE ElementoMenu = ? AND ElementoDispensa = ?",
                quantita, elemMenu, elemDispensa);
    }

    @Override
    public void eliminaIngrediente(String elemMenu, String elemDispensa) {
        jdbcTemplate.update("DELETE FROM INGREDIENTI WHERE ElementoMenu = ? AND ElementoDispensa = ?",
                elemMenu, elemDispensa);
    }

    @Override
    public void eliminaIngredientiElemMenu(String elemMenu) {
        jdbcTemplate.update("DELETE FROM INGREDIENTI WHERE ElementoMenu = ?",
                elemMenu);
    }

    @Override
    public void eliminaTuttiIngredienti() {
        jdbcTemplate.update("DELETE FROM INGREDIENTI");
    }

    @Override
    public String recuperaIngrediente(String elemMenu, String elemDispensa) {
        return jdbcTemplate.queryForObject("SELECT * FROM INGREDIENTI WHERE ElementoMenu = ? AND ElementoDispensa = ?",
                String.class, elemMenu, elemDispensa);
    }

    @Override
    public List<String> recuperaIngredientiByElemMenu(String elemMenu) {
        return jdbcTemplate.query("SELECT * FROM INGREDIENTI WHERE ElementoMenu = ?",
                new StringDataMapper(), elemMenu);
    }

    @Override
    public List<String> recuperaTuttiIngredienti() {
        return jdbcTemplate.query("SELECT * FROM INGREDIENTI", new StringDataMapper());
    }

    @Override
    public Float recuperaQuantitaIngrediente(String elemMenu, String elemDispensa) {
        return jdbcTemplate.queryForObject("SELECT Quantita FROM INGREDIENTI WHERE ElementoMenu = ? AND ElementoDispensa = ?",
                Float.class);
    }

    @Override
    public String recuperaUdMIngrediente(String elemMenu, String elemDispensa) {
        return jdbcTemplate.queryForObject("SELECT UdM FROM INGREDIENTI WHERE ElementoMenu = ? AND ElementoDispensa = ?",
                String.class);
    }

    @Override
    public List<String> recuperaElemDispensaIngredientiByElemMenu(String elemMenu) {
        return jdbcTemplate.query("SELECT ElementoDispensa FROM INGREDIENTI WHERE ElementoMenu = ?",
                new StringDataMapper(), elemMenu);
    }
}
