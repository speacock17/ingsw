package ingsw.server.interfacceDAO;


import java.util.List;

public interface BachecaEstesaDAO {
    public List<String> recuperaTuttaBacheca();
    public List<String> recuperaBachecaByDestinatario(String destinatario);
    public List<String> recuperaVisibiliByDestinatario(String destinatario);
    public List<String> recuperaNascostiByDestinatario(String destinatario);
    public List<String> recuperaVistiByDestinatario(String destinatario);
    public List<String> recuperaVistiNascostiByDestinatario(String destinatario);
}
