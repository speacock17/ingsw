package ingsw.server.controller;

import ingsw.server.entityDTO.bachecaDTO.ModNascostoDTO;
import ingsw.server.entityDTO.bachecaDTO.ModVisualizzatoDTO;
import ingsw.server.factoryDAO.BachecaFactory;
import ingsw.server.interfacceDAO.BachecaDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("controller/bacheca")
public class BachecaController{
    @Autowired
    BachecaDAO dao = BachecaFactory.getImplementation();

    @PatchMapping("modifica/nascosto")
    public ResponseEntity<String> updateStatoNascostoBacheca(@RequestBody ModNascostoDTO input){
        try{
            dao.modificaNascosto(input.getNascosto(), input.getIdAvviso(), input.getUsername());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("modifica/visualizzato")
    public ResponseEntity<String> updateStatoVisualizzatoBacheca(@RequestBody ModVisualizzatoDTO input){
        try{
            dao.modificaVisualizzato(input.getVisualizzato(), input.getIdAvviso(), input.getUsername());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
