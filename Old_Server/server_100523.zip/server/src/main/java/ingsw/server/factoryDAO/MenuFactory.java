package ingsw.server.factoryDAO;

import ingsw.server.factoryLogic.LeggiModelXML;
import ingsw.server.interfacceDAO.MenuDAO;
import ingsw.server.postgreDAO.MenuPostgreImpl;

public class MenuFactory {
    public static MenuDAO getImplementation(){
        String storage = LeggiModelXML.getStorage("Menu");
        if(storage.equals("PostgreSQL"))
            return new MenuPostgreImpl();
        else return null;
    }
}
