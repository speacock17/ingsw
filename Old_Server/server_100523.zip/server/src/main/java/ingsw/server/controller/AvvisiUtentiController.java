package ingsw.server.controller;

import ingsw.server.factoryDAO.AvvisoFactory;
import ingsw.server.factoryDAO.BachecaFactory;
import ingsw.server.factoryDAO.MittenteUtenteFactory;
import ingsw.server.factoryDAO.UtenteFactory;
import ingsw.server.interfacceDAO.AvvisoDAO;
import ingsw.server.interfacceDAO.BachecaDAO;
import ingsw.server.interfacceDAO.MittenteUtenteDAO;
import ingsw.server.entityDTO.mittenteUtenteDTO.MailFormDTO;
import ingsw.server.interfacceDAO.UtenteDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("controller/avvisiUtente")
public class AvvisiUtentiController{
    @Autowired
    MittenteUtenteDAO mittenteUdao = MittenteUtenteFactory.getImplementation();
    @Autowired
    AvvisoDAO avvisoDao = AvvisoFactory.getImplementation();
    @Autowired
    UtenteDAO utenteDao = UtenteFactory.getImplementation();
    @Autowired
    BachecaDAO bachecaDao = BachecaFactory.getImplementation();

    @PostMapping("scriveAvviso")
    public ResponseEntity<String> scriveAvviso(@RequestBody MailFormDTO input) {
        // effettua la registrazione nel database di un nuovo Avviso SCRITTO DA UN UTENTE
        try {
            // creo l'avviso
            avvisoDao.inserisciAvviso(input.getOggetto(), input.getTesto());

            // recupero l'idAvviso dell'ultimo avviso inserito
            Integer idAvviso = avvisoDao.recuperaIdUltimoAvviso();

            // assegno l'avviso creato all'utente (AUTORE) che lo ha creato
            mittenteUdao.scriveAvviso(input.getUsername(), idAvviso);

            // recupero tutti i dipendenti
            List<String> listaUsernameUtenti = utenteDao.recuperaUsernameTuttiUtenti();

            // lo aggiungo alla bacheca di tutti i dipendenti
            for (int i = 0; i < listaUsernameUtenti.size(); i++) {
                bachecaDao.inserisciBacheca(false, false,
                        idAvviso, listaUsernameUtenti.get(i));
            }
            return ResponseEntity.ok().body("Registrazione effettuata");
        } catch (DataAccessException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
