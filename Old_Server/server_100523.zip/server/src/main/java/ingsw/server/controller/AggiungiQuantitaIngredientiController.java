package ingsw.server.controller;

import ingsw.server.entityDTO.dispensaDTO.AggiungiQtaElemDispDTO;
import ingsw.server.factoryDAO.IngredientiFactory;
import ingsw.server.factoryDAO.OrdineFactory;
import ingsw.server.interfacceDAO.IngredientiDAO;
import ingsw.server.interfacceDAO.OrdineDAO;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;

import java.util.List;

public class AggiungiQuantitaIngredientiController {
    OrdineDAO ordineDao = OrdineFactory.getImplementation();
    IngredientiDAO ingredientiDao = IngredientiFactory.getImplementation();

    private final String SUCCESSO = "SUCCESSO";
    private final String FALLIMENTO = "FALLIMENTO";

    public String reinserisciIngredientiOrdine(Integer idOrdine){
        try {
            // recupero il nome dell'elemento ordinato
            String elementoMenu = ordineDao.recuperElemMenuOrdineById(idOrdine);

            // recupero gli ingredienti dell'elemento del menu
            List<String> lista = ingredientiDao.recuperaElemDispensaIngredientiByElemMenu(elementoMenu);

            // finche ci sono ingredienti da scorrere
            for(int i=0; i<lista.size(); i++){
                // recupero il nome dell'ingrediente corrente
                String elemDispensa = lista.get(i);

                // recupero la quantita necessaria dell'ingrediente
                Float quantitaNecessaria = ingredientiDao.recuperaQuantitaIngrediente(elementoMenu, elemDispensa);

                // eseguo l'aggiunta in dispensa
                AggiungiQtaElemDispDTO aggiungiDTO = new AggiungiQtaElemDispDTO(elemDispensa, quantitaNecessaria);
                ModificaQuantitaDispensaController riduciController = new ModificaQuantitaDispensaController();

                ResponseEntity<String> risultato = riduciController.aggiungiQuantitaElem(aggiungiDTO);
                if(risultato.getStatusCode().is2xxSuccessful())     continue;
                else return FALLIMENTO;
            }

            // se la computazione dello scorrimento del resultSet termina, vuol dire che e' andato tutto bene
            return SUCCESSO;

        } catch (DataAccessException e){
            return FALLIMENTO;
        }
    }
}
