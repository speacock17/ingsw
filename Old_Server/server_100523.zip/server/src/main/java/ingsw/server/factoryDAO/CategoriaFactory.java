package ingsw.server.factoryDAO;

import ingsw.server.factoryLogic.LeggiModelXML;
import ingsw.server.interfacceDAO.CategoriaDAO;
import ingsw.server.postgreDAO.CategoriaPostgreImpl;

public class CategoriaFactory {
    public static CategoriaDAO getImplementation(){
        String storage = LeggiModelXML.getStorage("Categoria");
        if(storage.equals("PostgreSQL"))
            return new CategoriaPostgreImpl();
        else return null;
    }
}
