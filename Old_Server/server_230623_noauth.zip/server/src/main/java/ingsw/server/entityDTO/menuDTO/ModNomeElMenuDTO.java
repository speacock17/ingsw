package ingsw.server.entityDTO.menuDTO;

public class ModNomeElMenuDTO {
    private String nome;
    private String newName;

    public String getNome() {
        return nome;
    }

    public String getNewName() {
        return newName;
    }
}
