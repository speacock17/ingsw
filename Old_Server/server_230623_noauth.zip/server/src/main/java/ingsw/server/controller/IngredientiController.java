package ingsw.server.controller;

import ingsw.server.entityDTO.ingredientiDTO.*;
import ingsw.server.interfacceDAO.DispensaDAO;
import ingsw.server.interfacceDAO.IngredientiDAO;
import ingsw.server.interfacceDAO.MenuDAO;
import ingsw.server.responseBodyBuilder.SendListaStringhe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("controller/ingredienti")
public class IngredientiController{
    private final IngredientiDAO ingredientiDao;
    private final MenuDAO menuDao;
    private final DispensaDAO dispensaDao;

    @Autowired
    public IngredientiController(IngredientiDAO ingredientiDao, MenuDAO menuDao, DispensaDAO dispensaDao) {
        this.ingredientiDao = ingredientiDao;
        this.menuDao = menuDao;
        this.dispensaDao = dispensaDao;
    }

    private Boolean validoQuantita(Float quantita){
        if(quantita == null)
            return false;
        return quantita > 0;
    }

    private Boolean esisteElemMenu(String elemMenu){
        try {
            String bin = menuDao.recuperaNomeMenuByNome(elemMenu);
            return true;
        } catch (DataAccessException e){
            return false;
        }
    }

    private Boolean esisteElemDispensa(String elemDispensa){
        try {
            String bin = dispensaDao.recuperaNomeDispensaByNome(elemDispensa);
            return true;
        } catch (DataAccessException e){
            return false;
        }
    }

    @PostMapping("registra")
    public ResponseEntity<String> insertIngredienti(@RequestBody IngredientiFormDTO input){
        // effettua la registrazione nel database di un nuovo ingrediente per elemento menu
        try{
            if(!validoQuantita(input.getQuantita()))
                return ResponseEntity.badRequest().body("Errore: quantita non valida");

            if(!esisteElemMenu(input.getElementoMenu()))
                return ResponseEntity.badRequest().body("Errore: Elemento menu non trovato");

            if(!esisteElemDispensa(input.getElementoDispensa()))
                return ResponseEntity.badRequest().body("Errore: Elemento dispensa non trovato");

            // recupero l'Unita di misura dell'elemento in dispensa
            String UdM = dispensaDao.recuperaUdMDispensaByNome(input.getElementoDispensa());

            ingredientiDao.inserisciIngredienti(
                input.getQuantita(),
                UdM,
                input.getElementoMenu(),
                input.getElementoDispensa()
            );
            return ResponseEntity.ok().body("Registrazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/quantita")
    public ResponseEntity<String> updateQuantitaIngredienti(@RequestBody IngredientiFormDTO input){
        // effettua la modifica della quantita dell'elem in dispensa necessaria come ingrediente per l'elemento menu
        try{
            ingredientiDao.modificaQuantita(input.getElementoMenu(), input.getElementoDispensa(), input.getQuantita());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/ingrediente")
    public ResponseEntity<String> deleteIngrediente(@RequestBody IndividuaIngredienteDTO input){
        // elimina un ingrediente
        try{
            ingredientiDao.eliminaIngrediente(input.getElementoMenu(), input.getElementoDispensa());
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/tuttiIngredienti")
    public ResponseEntity<String> deleteTuttiIngredienti(){
        // elimina tutti gli ingredienti di tutti gli elementi del menu
        try{
            ingredientiDao.eliminaTuttiIngredienti();
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/ingrediente")
    public ResponseEntity<String> recuperaIngrediente(@RequestBody IndividuaIngredienteDTO input){
        // recupera un ingrediente
        try{
            String query = ingredientiDao.recuperaIngrediente(input.getElementoMenu(), input.getElementoDispensa());
            return ResponseEntity.ok().body(query);
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/ingredientiByElementoMenu")
    public ResponseEntity<String> recuperaIngredientiByElemMenu(@RequestBody NomeElemMenuDTO input){
        // recupera gli ingredienti di un elemento del menu
        try{
            List<String> lista = ingredientiDao.recuperaIngredientiByElemMenu(input.getElementoMenu());
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/tuttiIngredienti")
    public ResponseEntity<String> recuperaTuttiIngredienti(){
        // recupera tutti gli ingredienti degli elementi del menu
        try{
            List<String> lista = ingredientiDao.recuperaTuttiIngredienti();
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
