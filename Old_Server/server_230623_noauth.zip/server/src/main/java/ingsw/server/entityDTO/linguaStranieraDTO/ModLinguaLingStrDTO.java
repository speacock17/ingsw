package ingsw.server.entityDTO.linguaStranieraDTO;

public class ModLinguaLingStrDTO {
    private String elementoMenu;
    private String lingua;

    public String getElementoMenu() {
        return elementoMenu;
    }

    public String getLingua() {
        return lingua;
    }
}
