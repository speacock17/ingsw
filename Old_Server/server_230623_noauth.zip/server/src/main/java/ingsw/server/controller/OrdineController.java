package ingsw.server.controller;

import ingsw.server.entityDTO.ordineDTO.OrdineFormDTO;
import ingsw.server.interfacceDAO.MenuDAO;
import ingsw.server.interfacceDAO.OrdineDAO;
import ingsw.server.responseBodyBuilder.SendListaStringhe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("controller/ordine")
public class OrdineController{
    private final OrdineDAO ordineDao;
    private final MenuDAO menuDao;
    private final RiduciQuantitaIngredientiController riduciQuantitaIngredientiController;
    private final AggiungiQuantitaIngredientiController aggiungiQuantitaIngredientiController;
    private final String SUCCESSO = "SUCCESSO";
    private final String FALLIMENTO = "FALLIMENTO";
    private final String INSUFFICIENTE = "INSUFFICIENTE";
    private final String DISPONIBILIE = "DISPONIBILE";

    @Autowired
    public OrdineController(
            OrdineDAO ordineDao,
            MenuDAO menuDao,
            RiduciQuantitaIngredientiController riduciQuantitaIngredientiController,
            AggiungiQuantitaIngredientiController aggiungiQuantitaIngredientiController) {
        this.ordineDao = ordineDao;
        this.menuDao = menuDao;
        this.riduciQuantitaIngredientiController = riduciQuantitaIngredientiController;
        this.aggiungiQuantitaIngredientiController = aggiungiQuantitaIngredientiController;
    }

    @DeleteMapping("delete/ordineById")
    public ResponseEntity<String> deleteOrdineById(@RequestParam (value = "idOrdine") Integer idOrdine){
        // effettua l'eliminazione di un ordine
        try{
            ordineDao.eliminaOrdineById(idOrdine);
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("stornaOrdine")
    public ResponseEntity<String> stornaOrdine(@RequestParam (value = "idOrdine") Integer idOrdine){
        // storna un ordine rimettendo gli ingredienti in dispensa
        try{
            // reinserisco gli ingredienti in dispensa
            String reinserisciIngredienti = aggiungiQuantitaIngredientiController.reinserisciIngredientiOrdine(idOrdine);

            // controllo che sia andato tutto bene
            if(reinserisciIngredienti.equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Storno non riuscito");

            // se e' andato a buon fine elimino l'ordine
            return deleteOrdineById(idOrdine);
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    private Boolean esisteMenu(String elemMenu){
        try {
            menuDao.recuperaNomeMenuByNome(elemMenu);
            return true;
        } catch (DataAccessException e){
            return false;
        }
    }

    private Boolean validoTavolo(Integer numeroTavolo){
        if(numeroTavolo > 0)    return true;
        else return false;
    }

    @PostMapping("registra")
    public ResponseEntity<String> registraOrdine(@RequestBody OrdineFormDTO input){
        try{
            if(!validoTavolo(input.getNumeroTavolo()))
                return  ResponseEntity.badRequest().body("Errore: Numero Tavolo non valido");

            if(!esisteMenu(input.getElementoMenu())) {
                return ResponseEntity.badRequest().body("Errore: Elemento non trovato");
            }

            // inserisco l'ordine
            ordineDao.inserisciOrdine(input.getNumeroTavolo(),input.getElementoMenu());

            //riduco la quantita degli elementi
            String esitoRiduzioneDispensa = riduciQuantitaIngredientiController.riduciQuantitaIngredienti(input.getElementoMenu());

            if(esitoRiduzioneDispensa.equals(FALLIMENTO))
                return  ResponseEntity.badRequest().body("Errore nella riduzione della quantita degli elementi in dispensa");

            else if(esitoRiduzioneDispensa.equals(INSUFFICIENTE)){
                // recupero l'id dell'ordine appena inserito
                Integer idOrdine = ordineDao.recuperaIdUltimoOrdine();

                // elimino l'ordine appena ordine inserito
                ResponseEntity<String> eliminoOrdine = deleteOrdineById(idOrdine);

                // messaggio errore
                if(eliminoOrdine.getStatusCode().is2xxSuccessful())
                    return ResponseEntity.ok().body("Ordine non inserito per ingredienti INSUFFICIENTI in dispensa");

                else return ResponseEntity.badRequest()
                        .body("Errore nell'eliminazione dell'ordine, da eliminare per ingredienti INSUFFICIENTI in dispensa");
            }
            return ResponseEntity.ok().body("Registrazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/numeroTavolo")
    public ResponseEntity<String> updateNumTavolo(@RequestParam (value = "idOrdine") Integer idOrdine,
                                                  @RequestParam (value = "numTavolo") Integer numTavolo){
        // effettua la modifica del numero tavolo
        try{
            ordineDao.modificaNumTavoloById(
                    idOrdine,
                    numTavolo
            );
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/ordiniByNumTavolo")
    public ResponseEntity<String> deleteOrdiniByNumTavolo(@RequestParam (value = "numTavolo") Integer numTavolo){
        // effettua l'eliminazione di ordini in base al numero del tavolo
        try{
            // accedo alla DAO per recuperare le query legate all'entita Ordine
            ordineDao.eliminaOrdiniByTavolo(numTavolo);
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/tuttiOrdini")
    public ResponseEntity<String> deleteTuttiOrdini(){
        // effettua l'eliminazione di tutti gli ordini
        try{
            // accedo alla DAO per recuperare le query legate all'entita Ordine
            ordineDao.eliminaTuttiOrdini();
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/ordineById")
    ResponseEntity<String> recuperaOrdineById(@RequestParam (value = "idOrdine") Integer idOrdine){
        // recupera tutti i dati di UN SOLO ORDINE
        try{
            String query = ordineDao.recuperaOrdineById(idOrdine);
            return ResponseEntity.ok().body(query);
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/ordiniTavolo")
    ResponseEntity<String> recuperaOrdiniTavolo(@RequestParam (value = "numTavolo") Integer numTavolo){
        // recupera tutti i dati DEGLI ORDINI di un tavolo
        try{
            List<String> lista = ordineDao.recuperaOrdiniByNumTavolo(numTavolo);
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/tuttiOrdini")
    ResponseEntity<String> recuperaTuttiOrdini(){
        // recupera tutti gli ORDINI
        try{
            List<String> lista = ordineDao.recuperaTuttiOrdini();
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
