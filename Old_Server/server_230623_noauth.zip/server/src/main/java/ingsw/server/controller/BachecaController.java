package ingsw.server.controller;

import ingsw.server.entityDTO.bachecaDTO.ModNascostoDTO;
import ingsw.server.entityDTO.bachecaDTO.ModVisualizzatoDTO;
import ingsw.server.interfacceDAO.AvvisoDAO;
import ingsw.server.interfacceDAO.BachecaDAO;
import ingsw.server.interfacceDAO.UtenteDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("controller/bacheca")
public class BachecaController{
    private final BachecaDAO bachecaDao;
    private final AvvisoDAO avvisoDao;
    private final UtenteDAO utenteDao;

    @Autowired
    public BachecaController(
            BachecaDAO bachecaDao,
            AvvisoDAO avvisoDao,
            UtenteDAO utenteDao) {
        this.bachecaDao = bachecaDao;
        this.avvisoDao = avvisoDao;
        this.utenteDao = utenteDao;
    }

    private Boolean esisteUtente(String username){
        try {
            String bin = utenteDao.recuperaUtenteByUsername(username);
            return true;
        } catch (DataAccessException e){
            return false;
        }
    }

    private Boolean esisteAvviso(Integer idAvviso){
        try {
            Integer bin = avvisoDao.recuperaIdAvviso(idAvviso);
            return true;
        } catch (DataAccessException e){
            return false;
        }
    }

    @PatchMapping("modifica/nascosto")
    public ResponseEntity<String> updateStatoNascostoBacheca(@RequestBody ModNascostoDTO input){
        try{
            if(!esisteUtente(input.getUsername()))
                return ResponseEntity.badRequest().body("Errore: Utente non trovato");

            if(!esisteAvviso(input.getIdAvviso()))
                return ResponseEntity.badRequest().body("Errore: Avviso non trovato");

            bachecaDao.modificaNascosto(input.getNascosto(), input.getIdAvviso(), input.getUsername());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("modifica/visualizzato")
    public ResponseEntity<String> updateStatoVisualizzatoBacheca(@RequestBody ModVisualizzatoDTO input){
        try{
            if(!esisteUtente(input.getUsername()))
                return ResponseEntity.badRequest().body("Errore: Utente non trovato");

            if(!esisteAvviso(input.getIdAvviso()))
                return ResponseEntity.badRequest().body("Errore: Avviso non trovato");

            bachecaDao.modificaVisualizzato(input.getVisualizzato(), input.getIdAvviso(), input.getUsername());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
