package ingsw.server.controller;

import ingsw.server.entityDTO.categoriaDTO.CategFormDTO;
import ingsw.server.entityDTO.categoriaDTO.ModNomeCategDTO;
import ingsw.server.entityDTO.categoriaDTO.ModPostoMenuCategDTO;
import ingsw.server.entityDTO.categoriaDTO.NomeCategDTO;
import ingsw.server.interfacceDAO.CategoriaDAO;
import ingsw.server.responseBodyBuilder.SendListaStringhe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("controller/categoria")
public class CategoriaController{
    private final CategoriaDAO dao;

    @Autowired
    public CategoriaController(CategoriaDAO dao) {
        this.dao = dao;
    }

    @PostMapping("registra/inOrder")
    public ResponseEntity<String> inserisciCategoriaInOrder(@RequestBody NomeCategDTO input){
        try {
            // se non ci sono categorie inserite, la inserisco in prima posizione
            if(dao.recuperaTutteCategorie() == null)
                dao.inserisciCategoria(input.getNome(), 1);

            else{
                Integer ultimoPosto = dao.recuperaUltimoPosto();
                dao.inserisciCategoria(input.getNome(), ultimoPosto + 1);
            }
            return ResponseEntity.ok().body("Registrazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("registra/generico")
    public ResponseEntity<String> inserisciCategoriaGenerica(@RequestBody CategFormDTO input){
        try {
            dao.inserisciCategoria(input.getNome(), input.getPostoMenu());
            return ResponseEntity.ok().body("Registrazione effettuata");
        }catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/nome")
    public ResponseEntity<String> updateNomeCategoria(@RequestBody ModNomeCategDTO input){
        try{
            dao.modificaNomeCategoria(input.getNome(), input.getNewName());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PatchMapping("update/postoMenu")
    public ResponseEntity<String> updatePostoMenuCategoria(@RequestBody ModPostoMenuCategDTO input){
        try {
            dao.modificaPostoCategoria(input.getNome(), input.getPostoMenu());
            return ResponseEntity.ok().body("Modifica effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/categoria")
    public ResponseEntity<String> deleteCategByNome(@RequestBody NomeCategDTO input){
        try {
            dao.eliminaCategoriaByNome(input.getNome());
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/tutteCategorie")
    public ResponseEntity<String> deleteTutteCateg(){
        try {
            dao.eliminaTutteCategorie();
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/categoria")
    public ResponseEntity<String> recuperaCategoriaByNome(@RequestBody NomeCategDTO input){
        // restituisce una stringa elencata di nome e posto nel menu di una categoria precisa
        try {
            String query = dao.recuperaCategoriaByNome(input.getNome());
            return ResponseEntity.ok().body(query);
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/tutteCategorie")
    public ResponseEntity<String> recuperaTutteCateg(){
        // restituisce una stringa elencata di nome e posto nel menu di TUTTE le categorie
        try {
            List<String> lista = dao.recuperaTutteCategorie();
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
