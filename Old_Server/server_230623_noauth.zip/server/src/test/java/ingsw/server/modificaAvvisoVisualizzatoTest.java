package ingsw.server;

import ingsw.server.interfacceDAO.AvvisoDAO;
import ingsw.server.interfacceDAO.BachecaDAO;
import ingsw.server.interfacceDAO.UtenteDAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataAccessException;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class modificaAvvisoVisualizzatoTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UtenteDAO utenteDao;

    @Autowired
    private AvvisoDAO avvisoDao;

    @Autowired
    private BachecaDAO bachecaDao;

    private final String url = "http://localhost:8080/controller/bacheca/modifica/visualizzato";
    private final String username = "superuser";
    private final String oggetto = "oggetto di prova";
    private final String testo = "testo di prova";
    private Integer idAvviso;

    private String generaBody(String username, Integer idAvviso, Boolean visualizzato){
        return "{\"username\":\"" + username + "\",\"idAvviso\": \""
                + idAvviso + "\", \"visualizzato\":\"" + visualizzato.toString() + "\"}";
    }

    private MockHttpServletRequestBuilder generaRichiesta(String url, String body){
        return MockMvcRequestBuilders.patch(url)
                .contentType(MediaType.APPLICATION_JSON)
                .content(body);
    }

    @BeforeEach
    void init(){
        // inserisci un utente
        try{
            utenteDao.inserisciUtente("superuser", "superuser", username , "superuser", "Admin");


            // inserisci l'avviso in bacheca
            String body = "{\"username\":\"" + username + "\",\"oggetto\": \""
                    + oggetto + "\", \"testo\":\"" + testo + "\"}";

            MockHttpServletRequestBuilder richiesta = MockMvcRequestBuilders.
                    post("http://localhost:8080/controller/avvisiUtente/scriveAvviso")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(body);

            // eseguo la richiesta
            mockMvc.perform(richiesta)
                    .andExpect(status().isOk());

            // recupera idAvviso appena creato
            idAvviso = avvisoDao.recuperaIdUltimoAvviso();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Avviso settato visualizzato con successo")
    void testVisualizzatoTrueAvvisoEsisteUtenteEsiste(){
        // ARRANGE
        String body = generaBody(username, idAvviso, true);

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isOk());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Avviso settato come NON visualizzato con successo")
    void testVisualizzatoFalseAvvisoEsisteUtenteEsiste(){
        // ARRANGE
        String body = generaBody(username, idAvviso, false);

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isOk());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Avviso non modificato - idAvviso non esiste")
    void testVisualizzatoTrueAvvisoNonEsisteUtenteEsiste(){
        // ARRANGE
        String body = generaBody(username, -1, true);

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Avviso non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Avviso non modificato - utente non esiste")
    void testVisualizzatoTrueAvvisoEsisteUtenteNonEsiste(){
        // ARRANGE
        String body = generaBody("nonEsisto", idAvviso, true);

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Utente non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Avviso non modificato - Nuovo stato visualizzato: NULL")
    void testVisualizzatoNullAvvisoEsisteUtenteEsiste(){
        // ARRANGE
        String body = "{\"username\":\"" + username + "\",\"idAvviso\": \""
                + idAvviso + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Avviso non modificato - idAvviso NULL")
    void testVisualizzatoTrueAvvisoNullUtenteEsiste(){
        // ARRANGE
        String body = "{\"username\":\"" + username + "\",\"visualizzato\": \""
                + true + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Avviso non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Avviso non modificato - utente NULL")
    void testVisualizzatoTrueAvvisoEsisteUtenteNull(){
        // ARRANGE
        String body = "{\"idAvviso\":\"" + idAvviso + "\",\"visualizzato\": \""
                + true + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Utente non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Avviso non modificato - Nuovo stato visualizzato: invalido")
    void testVisualizzatoInvalidAvvisoNullUtenteEsiste(){
        // ARRANGE
        String body = "{\"username\":\"" + username + "\",\"idAvviso\": \""
                + idAvviso + "\", \"visualizzato\":\"invalido\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Avviso non modificato - idAvviso vuoto")
    void testVisualizzatoTrueAvvisoVuotoUtenteEsiste(){
        // ARRANGE
        String body = "{\"username\":\"" + username + "\",\"idAvviso\": \"\", \"visualizzato\":\"" +
                true + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Avviso non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Avviso non modificato - utente vuoto")
    void testVisualizzatoTrueAvvisoEsisteUtenteVuoto(){
        // ARRANGE
        String body = generaBody("", idAvviso, true);

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Utente non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @AfterEach
    void done(){
        try {
            avvisoDao.eliminaAvvisoById(idAvviso);
            utenteDao.eliminaUtenteByUsername(username);
        } catch (DataAccessException e){
            System.out.println("Errore nel metodo done: " + e.getMessage());
        }
    }
}
