package ingsw.server.entityDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class OrdineDAO {
    private Connection connection;  // terra' traccia della connessione al Database
    // dichiaro le variabili in cui verranno inserite le query da eseguire:
    private PreparedStatement inserisciOrdinePS, recuperaOrdineByIdPS, recuperaTuttiOrdiniPS;
    private PreparedStatement recuperaUltimoOrdinePS, recuperaOrdineByNumTavoloPS, recuperaNumTavoloPS;
    private PreparedStatement modificaNumTavoloByIdPS, eliminaTuttiOrdiniPS;
    private PreparedStatement eliminaOrdiniByTavoloPS, eliminaOrdineByIdPS;

    public OrdineDAO(Connection conn) throws SQLException {
        connection = conn;              // imposto la connessione di riferimento (sulla base della quale verranno gestite le query)

        // compilo le query:
        inserisciOrdinePS = connection.prepareStatement("INSERT INTO Ordine VALUES (nextval('codOrdine'),?,?)");
        recuperaUltimoOrdinePS = connection.prepareStatement("SELECT * FROM Ordine WHERE IdOrdine = (SELECT max(IdOrdine) FROM Ordine)");
        recuperaNumTavoloPS = connection.prepareStatement("SELECT DISTINCT NumeroTavolo FROM Ordine WHERE NumeroTavolo = ?");
        recuperaOrdineByIdPS = connection.prepareStatement("SELECT * FROM Ordine WHERE IdOrdine = ?");
        recuperaTuttiOrdiniPS = connection.prepareStatement("SELECT * FROM Ordine");
        recuperaOrdineByNumTavoloPS = connection.prepareStatement("SELECT * FROM Ordine WHERE NumeroTavolo = ?");
        modificaNumTavoloByIdPS = connection.prepareStatement("UPDATE Ordine SET NumeroTavolo = ? WHERE IdOrdine = ?");
        eliminaTuttiOrdiniPS = connection.prepareStatement("DELETE FROM Ordine");
        eliminaOrdineByIdPS = connection.prepareStatement("DELETE FROM Ordine WHERE IdOrdine = ?");
        eliminaOrdiniByTavoloPS = connection.prepareStatement("DELETE FROM Ordine WHERE NumeroTavolo = ?");
    }
    /*
        Create table Ordine(
        IdOrdine integer NOT NULL,
        NumeroTavolo integer NOT NULL,
        Prodotto varchar(100) NOT NULL,
    */
    public void inserisciOrdine(Integer numeroTavolo, String prodotto) throws SQLException{
        inserisciOrdinePS.setInt(1, numeroTavolo);
        inserisciOrdinePS.setString(2, prodotto);
        inserisciOrdinePS.executeQuery();
    }

    public ResultSet recuperaUltimoOrdine() throws SQLException{
        return recuperaUltimoOrdinePS.executeQuery();
    }

    public ResultSet recuperaNumeroTavolo(Integer numeroTavolo) throws SQLException{
        recuperaNumTavoloPS.setInt(1, numeroTavolo);
        return recuperaNumTavoloPS.executeQuery();
    }
    public ResultSet recuperaOrdineById(Integer idOrdine) throws SQLException{
        recuperaOrdineByIdPS.setInt(1, idOrdine);
        return recuperaOrdineByIdPS.executeQuery();
    }
    public ResultSet recuperaTuttiOrdini() throws SQLException{
        return recuperaTuttiOrdiniPS.executeQuery();
    }
    public ResultSet recuperaOrdineByNumTavolo(Integer numeroTavolo) throws SQLException{
        recuperaOrdineByNumTavoloPS.setInt(1, numeroTavolo);
        return recuperaOrdineByNumTavoloPS.executeQuery();
    }
    public void modificaNumTavoloById(Integer idOrdine, Integer numeroTavolo) throws SQLException{
        modificaNumTavoloByIdPS.setInt(1, numeroTavolo);
        modificaNumTavoloByIdPS.setInt(2, idOrdine);
        modificaNumTavoloByIdPS.executeQuery();
    }

    public void eliminaTuttiOrdini() throws SQLException{
        eliminaTuttiOrdiniPS.executeQuery();
    }
    public void eliminaOrdineById(Integer idOrdine) throws SQLException{
        eliminaOrdineByIdPS.setInt(1, idOrdine);
        eliminaOrdineByIdPS.executeQuery();
    }

    public void eliminaOrdiniByTavolo(Integer numTavolo) throws SQLException{
        eliminaOrdiniByTavoloPS.setInt(1, numTavolo);
        eliminaOrdiniByTavoloPS.executeQuery();
    }
}
