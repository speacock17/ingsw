package ingsw.server.entityDTO.utenteDTO;

public class RegistraFormDTO {
    private String nome;
    private String cognome;
    private String username;
    private String password;

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}
