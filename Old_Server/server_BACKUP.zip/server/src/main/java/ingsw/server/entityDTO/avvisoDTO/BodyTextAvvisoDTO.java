package ingsw.server.entityDTO.avvisoDTO;

public class BodyTextAvvisoDTO {
    private String oggetto;
    private String testo;

    public String getOggetto() {
        return oggetto;
    }

    public String getTesto() {
        return testo;
    }
}
