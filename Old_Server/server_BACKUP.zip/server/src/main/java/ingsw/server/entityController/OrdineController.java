package ingsw.server.entityController;

import ingsw.server.entityDAO.DispensaDAO;
import ingsw.server.entityDAO.IngredientiDAO;
import ingsw.server.entityDAO.MenuDAO;
import ingsw.server.entityDAO.OrdineDAO;
import ingsw.server.entityDTO.dispensaDTO.AggiungiQtaElemDispDTO;
import ingsw.server.entityDTO.dispensaDTO.RiduciQtaElemDispDTO;
import ingsw.server.entityDTO.ordineDTO.OrdineFormDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.sql.ResultSet;
import java.sql.SQLException;

@RestController
@RequestMapping("controller/ordine")
public class OrdineController extends SuperController{
    private final String INSUFFICIENTE = "INSUFFICIENTE";
    private final String DISPONIBILIE = "DISPONIBILE";
    public OrdineController(JdbcTemplate jdbcTemplate) {
        super(jdbcTemplate);
    }

    public String esisteElemMenu(String nome){
        try{
            MenuDAO dao = new MenuDAO(connection);
            // recupero l'intero record dell' elemento del menu
            ResultSet rs = dao.recuperaMenuByNome(nome);
            if(rs == null)
                return FALLIMENTO;
            // estrapolo solo la colonna Nome
            String nomeDaRS = ottieniColonnaDaResultSetSingolaRiga(rs, 1);
            if(nomeDaRS == null)    // se non ho trovato l'elemento cercato
                return FALLIMENTO;
            else{
                if(nomeDaRS.equals(nome)) return nome;
                else return FALLIMENTO;
            }
        }catch (SQLException e){
            return handleSQLException(e);
        }
    }

    private String confrontaInteroEstringa(Integer intero, String stringa){
        String intToString = intero.toString();
        if(intToString.equals(stringa))
            return stringa;
        else return FALLIMENTO;
    }

    private String esisteOrdine(Integer idOrdine){
        try{
            OrdineDAO dao = new OrdineDAO(connection);

            // recupero l'intero record dell' elemento dell'ordine
            ResultSet rs = dao.recuperaOrdineById(idOrdine);
            if(rs == null)
                return FALLIMENTO;
            // estrapolo solo la colonna idOrdine
            String ordineDaRS = ottieniColonnaDaResultSetSingolaRiga(rs, 1);
            if(ordineDaRS == null)    // se non ho trovato l'elemento cercato
                return FALLIMENTO;
            else
                return confrontaInteroEstringa(idOrdine, ordineDaRS);
        }catch (SQLException e){
            return handleSQLException(e);
        }
    }

    @DeleteMapping("delete/ordineById")
    public ResponseEntity<String> deleteOrdineById(@RequestParam (value = "idOrdine") Integer idOrdine){
        // effettua l'eliminazione di un ordine
        try{
            // accedo alla DAO per recuperare le query legate all'entita Ordine
            OrdineDAO dao = new OrdineDAO(connection);

            // controllo che esiste il'id ordine inserito
            if(esisteOrdine(idOrdine).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Ordine non trovato");

            dao.eliminaOrdineById(idOrdine);

        }catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return eliminazioneEffettuata(esitoQuery);
    }

    private String esisteTavolo(Integer numTavolo){
        try{
            OrdineDAO dao = new OrdineDAO(connection);

            // recupero il numero tavolo
            ResultSet rs = dao.recuperaNumeroTavolo(numTavolo);
            if(rs == null)
                return FALLIMENTO;
            // estrapolo solo la colonna numTavolo
            String tavoloDaRS = ottieniColonnaDaResultSetSingolaRiga(rs, 1);
            if(tavoloDaRS == null)    // se non ho trovato l'elemento cercato
                return FALLIMENTO;
            else
                return confrontaInteroEstringa(numTavolo, tavoloDaRS);
        }catch (SQLException e){
            return handleSQLException(e);
        }
    }

    private String recuperaUltimoOrdine(){
        try{
            OrdineDAO dao = new OrdineDAO(connection);

            // recupero l'intero record dell' elemento del menu
            ResultSet rs = dao.recuperaUltimoOrdine();
            if(rs == null)
                return FALLIMENTO;

            // estrapolo solo la colonna idOrdine
            return ottieniColonnaDaResultSetSingolaRiga(rs, 1);


        }catch (SQLException e){
            return handleSQLException(e);
        }
    }


    private String insertOrdine(Integer numTavolo, String elemMenu){
        // effettua l'inserimento di un nuovo ordine nel database
        try{
            // accedo alla DAO per recuperare le query legate all'entita Ordine
            OrdineDAO dao = new OrdineDAO(connection);

            dao.inserisciOrdine(
                    numTavolo,
                    elemMenu
            );

        }catch(SQLException e){
            // la insert nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui gestisco l'eccezione (inevitabile) dell' inserimento
        return esitoQuery;
    }

    private String ottieniQuantitaElemDispensa(String elemDispensa){
        try{
            DispensaDAO dao = new DispensaDAO(connection);

            ResultSet rs = dao.recuperaElemDispensaByNome(elemDispensa);
            return ottieniColonnaDaResultSetSingolaRiga(rs, 5);
        }catch(SQLException e){
            esitoQuery = super.handleSQLException(e);
            return esitoQuery;
        }
    }

    private String verificaDisponibilita(String disponibilita, String riduzione){
        Float dispo = Float.valueOf(disponibilita);
        Float riduz = Float.valueOf(riduzione);
        if(riduz <= dispo)   return DISPONIBILIE;
        else return INSUFFICIENTE;
    }

    private String riduciQuantitaIngredienti(String elemMenu){
        // riduci la quantita degli ingredienti dell' elemento del menu
        try{
            // recupero gli ingredienti dell'elemento del menu
            IngredientiDAO dao = new IngredientiDAO(connection);

            ResultSet rs = dao.recuperaIngredientiByElemMenu(elemMenu);
            // controllo di averli recuperati con successo
            if(rs == null)
                return FALLIMENTO;

            // finche ci sono ingredienti da scorrere
            while(rs.next()){
                // recupero la quantita necessaria dell'ingrediente
                String quantitaNecessaria = rs.getString(1);

                // recupero il nome dell'ingrediente corrente
                String elemDispensa = rs.getString(4);

                // recupero la quantita a disposizione dell' elemento in dispensa
                String quantitaDisponibile = ottieniQuantitaElemDispensa(elemDispensa);

                // controllo vada tutto bene
                if(quantitaDisponibile.equals(FALLIMENTO))     return FALLIMENTO;

                // controllo che ci sia abbastanza quantita in dispensa
                String dispo = verificaDisponibilita(quantitaDisponibile, quantitaNecessaria);

                if(dispo.equals(FALLIMENTO))    return FALLIMENTO;

                if(dispo.equals(INSUFFICIENTE))   return INSUFFICIENTE;

                if(dispo.equals(DISPONIBILIE)){
                    Float togli = Float.valueOf(quantitaNecessaria);

                    RiduciQtaElemDispDTO riduci = new RiduciQtaElemDispDTO(elemDispensa, togli);
                    RiduciDispensaController riduciController = new RiduciDispensaController(jdbc);

                    ResponseEntity<String> risultato = riduciController.riduciQtaElemDispensa(riduci);
                    if(risultato.getStatusCode().is2xxSuccessful())     continue;
                    else return FALLIMENTO;
                }
            }

            // se la computazione dello scorrimento del resultSet termina, vuol dire che e' andato tutto bene
            return SUCCESSO;

        } catch (SQLException e){
            esitoQuery = super.handleSQLException(e);
            return esitoQuery;
        }
    }

    @PostMapping("registra")
    public ResponseEntity<String> registraOrdine(@RequestBody OrdineFormDTO input){
        System.out.println(input.getElementoMenu());
        // controllo che esiste l'elemento del menu inserito
        if(esisteElemMenu(input.getElementoMenu()).equals(FALLIMENTO))
            return ResponseEntity.badRequest().body("Elemento del menu non trovato");

        // inserisco l'ordine
        if(insertOrdine(
                input.getNumeroTavolo(),
                input.getElementoMenu()
                ).equals(FALLIMENTO))
            return ResponseEntity.badRequest().body("Errore nell'inserimento dell'ordine");

        // recupero l'id dell'ordine appena inserito
        String idOrdine = recuperaUltimoOrdine();
        // controllo di averlo recuperato con successo
        if(idOrdine.equals(FALLIMENTO))
            return ResponseEntity.badRequest().body("Errore nel recupero dell'ordine appena inserito");

        // riduco la quantita degli elementi
        String esitoRiduzioneDispensa = riduciQuantitaIngredienti(input.getElementoMenu());

        if(esitoRiduzioneDispensa.equals(FALLIMENTO))
            return  ResponseEntity.badRequest().body("Errore nella riduzione della quantita degli elementi in dispensa");

        else if(esitoRiduzioneDispensa.equals(INSUFFICIENTE)){
            // trasformo in intero l'id ordine
            Integer idOrdineIntero = Integer.valueOf(idOrdine);

            // elimino l'ordine appena ordine inserito
            ResponseEntity<String> eliminoOrdine = deleteOrdineById(idOrdineIntero);

            // messaggio errore
            if(eliminoOrdine.getStatusCode().is2xxSuccessful())
                return ResponseEntity.status(HttpStatus.OK).body("Ordine non inserito per ingredienti INSUFFICIENTI in dispensa");

            else return ResponseEntity.badRequest()
                    .body("Errore nell'eliminazione dell'ordine, da eliminare per ingredienti INSUFFICIENTI in dispensa");
        }
        else return registrazioneEffettuata(esitoQuery);
    }

    @PatchMapping("update/numeroTavolo")
    public ResponseEntity<String> updateNumTavolo(@RequestParam (value = "idOrdine") Integer idOrdine,
                                                  @RequestParam (value = "numTavolo") Integer numTavolo){
        // effettua la modifica del numero tavolo
        try{
            // accedo alla DAO per recuperare le query legate all'entita Ordine
            OrdineDAO dao = new OrdineDAO(connection);

            // controllo che esiste il'id ordine inserito
            if(esisteOrdine(idOrdine).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Ordine non trovato");

            dao.modificaNumTavoloById(
                    idOrdine,
                    numTavolo
            );
        }catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return modificaEffettuata(esitoQuery);
    }

    @DeleteMapping("delete/ordiniByNumTavolo")
    public ResponseEntity<String> deleteOrdiniByNumTavolo(@RequestParam (value = "numTavolo") Integer numTavolo){
        // effettua l'eliminazione di ordini in base al numero del tavolo
        try{
            // accedo alla DAO per recuperare le query legate all'entita Ordine
            OrdineDAO dao = new OrdineDAO(connection);

            if(esisteTavolo(numTavolo).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Tavolo non trovato");

            dao.eliminaOrdiniByTavolo(numTavolo);

        }catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return eliminazioneEffettuata(esitoQuery);
    }

    @DeleteMapping("delete/tuttiOrdini")
    public ResponseEntity<String> deleteTuttiOrdini(){
        // effettua l'eliminazione di tutti gli ordini
        try{
            // accedo alla DAO per recuperare le query legate all'entita Ordine
            OrdineDAO dao = new OrdineDAO(connection);

            dao.eliminaTuttiOrdini();

        }catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return eliminazioneEffettuata(esitoQuery);
    }

    @GetMapping("recupera/ordineById")
    ResponseEntity<String> recuperaOrdineById(@RequestParam (value = "idOrdine") Integer idOrdine){
        // recupera tutti i dati di UN SOLO ORDINE
        try{
            // accedo alla DAO per recuperare le query legate all'entita Ordine
            OrdineDAO dao = new OrdineDAO(connection);

            // controllo che esiste il'id ordine inserito
            if(esisteOrdine(idOrdine).equals(FALLIMENTO))
                ResponseEntity.badRequest().body("Ordine non trovato");

            ResultSet rs = dao.recuperaOrdineById(idOrdine);
            return ResponseEntity.status(HttpStatus.OK).body(componiDaResultSet(rs));
        } catch (SQLException e){
            esitoQuery = super.handleSQLException(e);
            return ResponseEntity.badRequest().body(esitoQuery);
        }
    }

    @GetMapping("recupera/ordiniTavolo")
    ResponseEntity<String> recuperaOrdiniTavolo(@RequestParam (value = "numTavolo") Integer numTavolo){
        // recupera tutti i dati DEGLI ORDINI di un tavolo
        try{
            // accedo alla DAO per recuperare le query legate all'entita Ordine
            OrdineDAO dao = new OrdineDAO(connection);

            if(esisteTavolo(numTavolo).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Tavolo non trovato");

            ResultSet rs = dao.recuperaOrdineByNumTavolo(numTavolo);
            return ResponseEntity.status(HttpStatus.OK).body(componiDaResultSet(rs));
        } catch (SQLException e){
            esitoQuery = super.handleSQLException(e);
            return ResponseEntity.badRequest().body(esitoQuery);
        }
    }

    @GetMapping("recupera/tuttiOrdini")
    ResponseEntity<String> recuperaTuttiOrdini(){
        // recupera tutti gli ORDINI
        try{
            // accedo alla DAO per recuperare le query legate all'entita Ordine
            OrdineDAO dao = new OrdineDAO(connection);

            ResultSet rs = dao.recuperaTuttiOrdini();
            return ResponseEntity.status(HttpStatus.OK).body(componiDaResultSet(rs));
        } catch (SQLException e){
            esitoQuery = super.handleSQLException(e);
            return ResponseEntity.badRequest().body(esitoQuery);
        }
    }

    private String ottieniElementoMenu(Integer idOrdine){
        try{
            // recupero l'intero record dell'ordine
            OrdineDAO daoOrdine = new OrdineDAO(connection);

            ResultSet rsOrdine = daoOrdine.recuperaOrdineById(idOrdine);
            if(rsOrdine == null)
                return FALLIMENTO;

            //estraggo l'elemento del menu ordinato
            return ottieniColonnaDaResultSetSingolaRiga(rsOrdine, 3);
        }catch (SQLException e){
            esitoQuery = this.handleSQLException(e);
            return esitoQuery;
        }
    }

    private String reinserisciIngredientiOrdine(Integer idOrdine){
        try {
            // recupero il nome dell'elemento ordinato
            String elementoMenu = ottieniElementoMenu(idOrdine);

            // recupero gli ingredienti dell'elemento del menu
            IngredientiDAO dao = new IngredientiDAO(connection);

            ResultSet rs = dao.recuperaIngredientiByElemMenu(elementoMenu);
            // controllo di averli recuperati con successo
            if(rs == null)
                return FALLIMENTO;

            // finche ci sono ingredienti da scorrere
            while(rs.next()){
                // recupero la quantita necessaria dell'ingrediente
                String quantitaNecessaria = rs.getString(1);

                // recupero il nome dell'ingrediente corrente
                String elemDispensa = rs.getString(4);

                // ricavo il valore in float
                Float aggiungi = Float.valueOf(quantitaNecessaria);

                // eseguo l'aggiunta in dispensa
                AggiungiQtaElemDispDTO aggiungiDTO = new AggiungiQtaElemDispDTO(elemDispensa, aggiungi);
                RiduciDispensaController riduciController = new RiduciDispensaController(jdbc);

                ResponseEntity<String> risultato = riduciController.aggiungiQuantitaElem(aggiungiDTO);
                if(risultato.getStatusCode().is2xxSuccessful())     continue;
                else return FALLIMENTO;
            }

            // se la computazione dello scorrimento del resultSet termina, vuol dire che e' andato tutto bene
            return SUCCESSO;

        } catch (SQLException e){
            esitoQuery = this.handleSQLException(e);
            return esitoQuery;
        }
    }

    @DeleteMapping("stornaOrdine")
    public ResponseEntity<String> stornaOrdine(@RequestParam (value = "idOrdine") Integer idOrdine){
        // storna un ordine rimettendo gli ingredienti in dispensa
        try{
            OrdineDAO dao = new OrdineDAO(connection);

            // controllo se esiste l'ordine indicato
            if(esisteOrdine(idOrdine).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Ordine non trovato");

            // reinserisco gli ingredienti in dispensa
            String reinserisciIngredienti = reinserisciIngredientiOrdine(idOrdine);

            // controllo che sia andato tutto bene
            if(reinserisciIngredienti.equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Storno non riuscito");

            // se e' andato a buon fine elimino l'ordine
            return deleteOrdineById(idOrdine);
        }catch(SQLException e){
            esitoQuery = super.handleSQLException(e);
            return ResponseEntity.badRequest().body(esitoQuery);
        }
    }
}
