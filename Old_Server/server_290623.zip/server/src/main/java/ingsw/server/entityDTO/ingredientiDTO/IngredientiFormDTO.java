package ingsw.server.entityDTO.ingredientiDTO;

public class IngredientiFormDTO {
    private String elementoMenu;
    private String elementoDispensa;
    private Float quantita;

    public String getElementoMenu() {
        return elementoMenu;
    }

    public String getElementoDispensa() {
        return elementoDispensa;
    }

    public Float getQuantita() {
        return quantita;
    }
}
