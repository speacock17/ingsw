package ingsw.server.entityDTO.dispensaDTO;

public class NomeElemDispDTO {
    private String nome;

    public String getNome() {
        return nome;
    }
}
