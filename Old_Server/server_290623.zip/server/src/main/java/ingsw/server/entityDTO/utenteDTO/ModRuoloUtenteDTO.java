package ingsw.server.entityDTO.utenteDTO;

public class ModRuoloUtenteDTO {
    String username;
    String ruolo;

    public String getUsername() {
        return username;
    }

    public String getRuolo() {
        return ruolo;
    }
}
