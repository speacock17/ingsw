package ingsw.server.interfacceDAO;

import java.util.List;

public interface UtenteDAO {
    /*
        Create table Utente(
    Nome varchar(50) NOT NULL,
    Cognome varchar(50) NOT NULL,
    Username varchar(50) NOT NULL,
    Pass varchar(50) NOT NULL,
    Ruolo tipoUtente NOT NULL,
    PrimoAccesso bool DEFAULT false,
    */

    public void inserisciUtente(String nome, String cognome, String username, String password, String ruolo);
    public void modificaNomeUtente(String username, String nome);
    public void modificaCognomeUtente(String username, String cognome);
    public void modificaUsernameUtente(String username, String newUsername);
    public void modificaPasswordUtente(String username, String password);
    public void modificaRuoloUtente(String username, String ruolo);
    public void modificaPrimoAccessoUtente(String username, Boolean accesso);
    public void eliminaUtenteByUsername(String username);
    public void eliminaUtentiByRuolo(String ruolo);
    public void eliminaTuttiUtenti();
    public String recuperaUtenteNoPassword(String username);
    public String recuperaPasswordByUsername(String username);
    public Boolean recuperaAccessoByUsername(String username);
    public String recuperaRuoloByUsername(String username);
    public String recuperaUtenteByUsername(String username);
    public List<String> recuperaUtentiByRuolo(String ruolo);
    public List<String> recuperaUsernameTuttiUtenti();
    public List<String> recuperaTuttiUtenti();
}
