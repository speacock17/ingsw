package ingsw.server.responseBodyBuilder;

import java.util.List;

public class SendListaStringhe {
    public static String sendString(List<String> lista){
        String body = new String("");
        for(int i=0; i<lista.size(); i++){
            body += lista.get(i);

            if(i<lista.size()-1)
                body += "\n\n";
        }
        return body;
    }
}
