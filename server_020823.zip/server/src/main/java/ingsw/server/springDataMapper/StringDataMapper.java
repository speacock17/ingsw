package ingsw.server.springDataMapper;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class StringDataMapper implements RowMapper<String>{
    @Override
    public String mapRow(ResultSet rs, int rowNum) throws SQLException{
        String risultato = new String("");

        for(int i = 1; i <= rs.getMetaData().getColumnCount(); i++){
            // compongo la stringa con ogni valore del risultato della query riga per riga e colonna per colonna
            risultato += rs.getMetaData().getColumnName(i) + " = " + rs.getString(i);

            if(i<rs.getMetaData().getColumnCount())
                risultato += "\n";
        }

        return risultato;
    }
}
