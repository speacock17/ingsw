package ingsw.server.openFoodData;

import org.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.net.ssl.HttpsURLConnection;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

@RestController
@RequestMapping("openFoodData")
public class OpenFoodDataController {
    private final LeggiJSON leggiJSON = new LeggiJSON();

    private String ottieniRisposta(HttpsURLConnection connection) throws Exception{
        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String line;
        StringBuilder response = new StringBuilder();
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();
        return response.toString();
    }

    private JSONObject effettuaRichiesta(URL url) throws Exception{
        // Apre una connessione HTTPS
        HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();

        // Imposta il metodo di richiesta (GET, POST, ecc.)
        connection.setRequestMethod("GET");

        // Legge la risposta dall'input stream
        String response = ottieniRisposta(connection);

        // Converti la risposta in un oggetto JSON
        JSONObject jsonResponse = new JSONObject(response);

        // Chiude la connessione
        connection.disconnect();
        return jsonResponse;
    }
    @GetMapping("getDescrizione")
    public ResponseEntity<String> ottieniDescrizione(@RequestParam(value = "id") String barcode){
        String url = "https://world.openfoodfacts.org/api/v0/product/" + barcode + ".json";

        try{
            // ottieni il file JSON da Open Food Facts
            JSONObject file = effettuaRichiesta(new URL(url));
            // ottieni i dati dal file JSON
            return ResponseEntity.ok().body(leggiJSON.getDescrizione(file));
        }catch (Exception e){
            return ResponseEntity.badRequest().body("File relativo al barcode not found.");
        }
    }
}
