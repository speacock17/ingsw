package ingsw.server.autenticazione;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class BCryptPassword {
    public static String criptaPassword(String password) {
        // Crea un oggetto BCryptPasswordEncoder con il parametro di forza (strength) desiderato
        // Il valore di default per la forza è 10, che determina il numero di iterazioni del processo di hash
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);

        // Effettua l'hash della password
        return encoder.encode(password);
    }
}
