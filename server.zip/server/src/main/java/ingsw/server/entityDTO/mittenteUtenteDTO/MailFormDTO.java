package ingsw.server.entityDTO.mittenteUtenteDTO;

public class MailFormDTO {
    private String username;
    private String oggetto;
    private String testo;

    public String getUsername() {
        return username;
    }

    public String getOggetto() {
        return oggetto;
    }

    public String getTesto() {
        return testo;
    }
}
