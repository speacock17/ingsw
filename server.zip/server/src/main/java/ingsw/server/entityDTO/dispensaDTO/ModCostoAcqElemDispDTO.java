package ingsw.server.entityDTO.dispensaDTO;

public class ModCostoAcqElemDispDTO {
    private String nome;
    private Float costoAcq;

    public String getNome() {
        return nome;
    }

    public Float getCostoAcq() {
        return costoAcq;
    }
}
