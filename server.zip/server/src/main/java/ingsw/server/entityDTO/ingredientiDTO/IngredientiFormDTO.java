package ingsw.server.entityDTO.ingredientiDTO;

public class IngredientiFormDTO {
    private String elementoMenu;
    private String elementoDispensa;
    private String unitaDiMisura;
    private Float quantita;

    public String getElementoMenu() {
        return elementoMenu;
    }

    public String getElementoDispensa() {
        return elementoDispensa;
    }

    public String getUnitaDiMisura() {
        return unitaDiMisura;
    }

    public Float getQuantita() {
        return quantita;
    }
}
