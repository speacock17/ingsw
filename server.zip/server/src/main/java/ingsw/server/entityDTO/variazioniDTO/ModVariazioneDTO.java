package ingsw.server.entityDTO.variazioniDTO;

public class ModVariazioneDTO {
    private String prodDispensa;
    private String tipoVariazione;

    public String getProdDispensa() {
        return prodDispensa;
    }

    public String getTipoVariazione() {
        return tipoVariazione;
    }
}
