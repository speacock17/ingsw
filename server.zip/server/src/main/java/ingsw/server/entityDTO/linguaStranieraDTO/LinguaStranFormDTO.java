package ingsw.server.entityDTO.linguaStranieraDTO;

public class LinguaStranFormDTO {
    private String lingua;
    private String nomeProdotto;
    private String descrizioneProdotto;
    private String allergeni;
    private String elementoMenu;

    public String getLingua() {
        return lingua;
    }

    public String getNomeProdotto() {
        return nomeProdotto;
    }

    public String getDescrizioneProdotto() {
        return descrizioneProdotto;
    }

    public String getAllergeni() {
        return allergeni;
    }

    public String getElementoMenu() {
        return elementoMenu;
    }
}
