package ingsw.server.entityDTO.ordineDTO;

public class OrdineFormDTO {
    private Integer numeroTavolo;
    private Integer quantita;
    private String elementoMenu;

    public Integer getNumeroTavolo() {
        return numeroTavolo;
    }

    public Integer getQuantita() {
        return quantita;
    }

    public String getElementoMenu() {
        return elementoMenu;
    }
}
