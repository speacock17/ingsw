package ingsw.server.entityDTO.variazioniDTO;

public class VariazioniFormDTO {
    private Integer idOrdine;
    private String prodDispensa;
    private String tipoVariazione;

    public Integer getIdOrdine() {
        return idOrdine;
    }

    public String getProdDispensa() {
        return prodDispensa;
    }

    public String getTipoVariazione() {
        return tipoVariazione;
    }
}
