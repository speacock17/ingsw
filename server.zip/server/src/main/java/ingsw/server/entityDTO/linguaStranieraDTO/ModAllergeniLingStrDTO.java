package ingsw.server.entityDTO.linguaStranieraDTO;

public class ModAllergeniLingStrDTO {
    private String elementoMenu;
    private String allergeni;

    public String getElementoMenu() {
        return elementoMenu;
    }

    public String getAllergeni() {
        return allergeni;
    }
}
