package ingsw.server.entityDTO.categoriaDTO;

public class ModPostoMenuCategDTO {
    private String nome;
    private Integer postoMenu;

    public String getNome() {
        return nome;
    }

    public Integer getPostoMenu() {
        return postoMenu;
    }
}
