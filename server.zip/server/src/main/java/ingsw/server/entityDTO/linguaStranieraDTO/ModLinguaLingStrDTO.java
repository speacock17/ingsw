package ingsw.server.entityDTO.linguaStranieraDTO;

public class ModLinguaLingStrDTO {
    private String elementoProdotto;
    private String lingua;

    public String getElementoProdotto() {
        return elementoProdotto;
    }

    public String getLingua() {
        return lingua;
    }
}
