package ingsw.server.entityDTO.menuDTO;

public class ModPostoCategElMenuDTO {
    private String nome;
    private Integer postoMenu;

    public String getNome() {
        return nome;
    }

    public Integer getPostoMenu() {
        return postoMenu;
    }
}
