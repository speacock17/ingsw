package ingsw.server.entityController;

import ingsw.server.entityDAO.LinguaStranieraDAO;
import ingsw.server.entityDAO.MenuDAO;
import ingsw.server.entityDTO.linguaStranieraDTO.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.sql.ResultSet;
import java.sql.SQLException;

@RestController
@RequestMapping("controller/linguaStraniera")
public class LinguaStranieraController extends SuperController{
    public LinguaStranieraController(JdbcTemplate jdbcTemplate) {
        super(jdbcTemplate);
    }

    public String esisteElemMenu(String nome){
        try{
            MenuDAO dao = new MenuDAO(connection);
            // recupero l'intero record dell' elemento del menu
            ResultSet rs = dao.recuperaMenuByNome(nome);
            if(rs == null)
                return FALLIMENTO;
            // estrapolo solo la colonna Nome
            String nomeDaRS = ottieniColonnaDaResultSetSingolaRiga(rs, 1);
            if(nomeDaRS == null)    // se non ho trovato l'elemento cercato
                return FALLIMENTO;
            else{
                if(nomeDaRS.equals(nome)) return nome;
                else return FALLIMENTO;
            }
        }catch (SQLException e){
            return handleSQLException(e);
        }
    }

    @PostMapping("registra")
    public ResponseEntity<String> insertElemMenuLingStr(@RequestBody LinguaStranFormDTO input){
        // effettua la registrazione nel database di un nuovo elemento del menu in LINGUA STRANIERA
        try{
            // accedo alla DAO per recuperare le query legate all'entita' lingua straniera
            LinguaStranieraDAO dao = new LinguaStranieraDAO(connection);

            if(esisteElemMenu(input.getElementoMenu()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento non trovato");

            dao.inserisciLinguaStraniera(
                    input.getLingua(),
                    input.getNomeProdotto(),
                    input.getDescrizioneProdotto(),
                    input.getElementoMenu()
            );
        }
        catch(SQLException e){
            // la insert nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return registrazioneEffettuata(esitoQuery);
    }

    @PatchMapping("update/lingua")
    public ResponseEntity<String> updateLinguaLingStr(@RequestBody ModLinguaLingStrDTO input){
        // modifica la lingua di un elemento descritto in LINGUA STRANIERA
        try{
            // accedo alla DAO per recuperare le query legate all'entita' lingua straniera
            LinguaStranieraDAO dao = new LinguaStranieraDAO(connection);

            if(esisteElemMenu(input.getElementoMenu()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento non trovato");

            dao.modificaLinguaElemLingStr(
                    input.getElementoMenu(),
                    input.getLingua()
            );
        }
        catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return modificaEffettuata(esitoQuery);
    }

    @PatchMapping("update/nome")
    public ResponseEntity<String> updateNomeLingStr(@RequestBody ModNomeProdLingStrDTO input){
        // modifica il nome di un elemento descritto in LINGUA STRANIERA
        try{
            // accedo alla DAO per recuperare le query legate all'entita' lingua straniera
            LinguaStranieraDAO dao = new LinguaStranieraDAO(connection);

            if(esisteElemMenu(input.getElementoMenu()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento non trovato");

            dao.modificaNomeLingStr(
                    input.getElementoMenu(),
                    input.getNomeProdotto()
            );
        }
        catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return modificaEffettuata(esitoQuery);
    }

    @PatchMapping("update/descrizione")
    public ResponseEntity<String> updateDescrLingStr(@RequestBody ModDescrLingStrDTO input){
        // modifica la descrizione di un elemento descritto in LINGUA STRANIERA
        try{
            // accedo alla DAO per recuperare le query legate all'entita' lingua straniera
            LinguaStranieraDAO dao = new LinguaStranieraDAO(connection);

            if(esisteElemMenu(input.getElementoMenu()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento non trovato");

            dao.modificaDescrElemMenu(
                    input.getElementoMenu(),
                    input.getDescrizione()
            );
        }
        catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return modificaEffettuata(esitoQuery);
    }

    @DeleteMapping("delete/elemento")
    public ResponseEntity<String> deleteElemLingStr(@RequestBody NomeElemMenuDTO input){
        // elimina un elemento descritto in LINGUA STRANIERA
        try{
            // accedo alla DAO per recuperare le query legate all'entita' lingua straniera
            LinguaStranieraDAO dao = new LinguaStranieraDAO(connection);

            if(esisteElemMenu(input.getElementoMenu()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento non trovato");

            dao.eliminaElemMenu(input.getElementoMenu());
        }
        catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return eliminazioneEffettuata(esitoQuery);
    }

    @DeleteMapping("delete/tuttaLinguaStraniera")
    public ResponseEntity<String> deleteTuttaLingStr(){
        // elimina tutti gli elementi in LINGUA STRANIERA
        try{
            // accedo alla DAO per recuperare le query legate all'entita' lingua straniera
            LinguaStranieraDAO dao = new LinguaStranieraDAO(connection);

            dao.eliminaTuttoMenu();
        }
        catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return eliminazioneEffettuata(esitoQuery);
    }

    @GetMapping("recupera/tuttaLinguaStraniera")
    public ResponseEntity<String> recuperaTuttaLingStr(){
        // recupera tutti gli elementi in LINGUA STRANIERA
        try{
            // accedo alla DAO per recuperare le query legate all'entita' lingua straniera
            LinguaStranieraDAO dao = new LinguaStranieraDAO(connection);

            ResultSet rs = dao.recuperaLinguaStraniera();
            return  ResponseEntity.status(HttpStatus.OK).body(componiDaResultSet(rs));
        }
        catch(SQLException e){
            esitoQuery = super.handleSQLException(e);
            return ResponseEntity.badRequest().body(esitoQuery);
        }
    }

    @GetMapping("recupera/elemento")
    public ResponseEntity<String> recuperaElementoLingStr(@RequestBody NomeElemMenuDTO input){
        // recupera un SOLO elemento in LINGUA STRANIERA
        try{
            // accedo alla DAO per recuperare le query legate all'entita' lingua straniera
            LinguaStranieraDAO dao = new LinguaStranieraDAO(connection);

            if(esisteElemMenu(input.getElementoMenu()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento non trovato");

            ResultSet rs = dao.recuperaElemLinguaStr(input.getElementoMenu());
            return  ResponseEntity.status(HttpStatus.OK).body(componiDaResultSet(rs));
        }
        catch(SQLException e){
            esitoQuery = super.handleSQLException(e);
            return ResponseEntity.badRequest().body(esitoQuery);
        }
    }
}
