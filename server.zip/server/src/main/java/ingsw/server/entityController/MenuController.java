package ingsw.server.entityController;

import ingsw.server.entityDAO.MenuDAO;
import ingsw.server.entityDTO.menuDTO.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.sql.ResultSet;
import java.sql.SQLException;

@RestController         //serve per poter usare le notazioni e mappare i metodi
@RequestMapping("controller/menu")      // definisce il path per accedere tramite http ai metodi di questo controller
public class MenuController extends SuperController{
    public MenuController(JdbcTemplate jdbcTemplate) {
        super(jdbcTemplate);
    }

    public String esisteElemMenu(String nome){
        try{
            MenuDAO dao = new MenuDAO(connection);
            // recupero l'intero record dell' elemento del menu
            ResultSet rs = dao.recuperaMenuByNome(nome);
            if(rs == null)
                return FALLIMENTO;
            // estrapolo solo la colonna Nome
            String nomeDaRS = ottieniColonnaDaResultSetSingolaRiga(rs, 1);
            if(nomeDaRS == null)    // se non ho trovato l'elemento cercato
                return FALLIMENTO;
            else{
                if(nomeDaRS.equals(nome)) return nome;
                else return FALLIMENTO;
            }
        }catch (SQLException e){
            return handleSQLException(e);
        }
    }
    @PostMapping("registra")
    public ResponseEntity<String> insertElemMenu(@RequestBody ElemMenuFormDTO input){
        // effettua la registrazione nel database di un nuovo elemento del menu
        try{
            // accedo alla DAO per recuperare le query legate all'entita' menu
            MenuDAO dao = new MenuDAO(connection);
            // controllo se esiste gia un utente con il nome inviato dal client
            if(esisteElemMenu(input.getNome()).equals(FALLIMENTO))
                // chiedo alla DAO di eseguire la query di inserimento
                dao.inserisciElemMenu(
                        input.getNome(),
                        input.getDescrizione(),
                        input.getCosto(),
                        input.getAllergeni(),
                        input.getCategoria()
                );
            else    // esiste gia un elemento in menu con questo nome
                return ResponseEntity.badRequest().body("Nome gia in uso");
        }
        catch(SQLException e){
            // la insert nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return registrazioneEffettuata(esitoQuery);
    }

    @GetMapping("recupera/elemMenu")
    public ResponseEntity<String> recuperaElemMenu(@RequestBody NomeElemMenuDTO input){
        // restituisce una stringa elencata con i valori:
        // nome, descrizione, costo, allergeni, categoria, posto categoria
        try{
            MenuDAO dao = new MenuDAO(connection);
            // controllo esistenza dell' elemento da cercare
            if(esisteElemMenu(input.getNome()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento non trovato");

            ResultSet rs = dao.recuperaMenuByNome(input.getNome());
            return  ResponseEntity.status(HttpStatus.OK).body(componiDaResultSet(rs));

        }catch (SQLException e){
            esitoQuery = super.handleSQLException(e);
            return ResponseEntity.badRequest().body(esitoQuery);
        }
    }

    @GetMapping("recupera/tuttoMenu")
    public ResponseEntity<String> recuperaTuttoMenu(){
        // restituisce tutti i valori di TUTTI gli elementi del menu
        try{
            MenuDAO dao = new MenuDAO(connection);

            ResultSet rs = dao.recuperaMenu();
            return  ResponseEntity.status(HttpStatus.OK).body(componiDaResultSet(rs));

        }catch (SQLException e){
            esitoQuery = super.handleSQLException(e);
            return ResponseEntity.badRequest().body(esitoQuery);
        }
    }

    @GetMapping("recupera/menuByCategoria")
    public ResponseEntity<String> recuperaMenuByCategoria(@RequestBody NomeCategMenuDTO input){
        // restituisce tutti i valori di TUTTI gli elementi di una CATEGORIA del menu
        try{
            MenuDAO dao = new MenuDAO(connection);
            // manca il controllo di esistenza categoria
            ResultSet rs = dao.recuperaMenuByCategoria(input.getCategoria());
            return  ResponseEntity.status(HttpStatus.OK).body(componiDaResultSet(rs));

        }catch (SQLException e){
            esitoQuery = super.handleSQLException(e);
            return ResponseEntity.badRequest().body(esitoQuery);
        }
    }

    @PatchMapping("update/nome")
    public ResponseEntity<String> updateNomeElemMenu(@RequestBody ModNomeElMenuDTO input){
        try{
            MenuDAO dao = new MenuDAO(connection);
            // controllo esistenza dell' elemento da modificare
            if(esisteElemMenu(input.getNome()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento non trovato");

            // controllo se il nuovo nome non sia gia in uso
            if(esisteElemMenu(input.getNewName()).equals(FALLIMENTO))
                dao.modificaNomeElemMenu(input.getNome(), input.getNewName());
            else
                return ResponseEntity.badRequest().body("Nome elemento menu gia in uso");
        } catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return modificaEffettuata(esitoQuery);
    }

    @PatchMapping("update/descrizione")
    public ResponseEntity<String> updateDescrElemMenu(@RequestBody ModDescrElMenuDTO input){
        try{
            MenuDAO dao = new MenuDAO(connection);
            // controllo esistenza dell' elemento da modificare
            if(esisteElemMenu(input.getNome()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento non trovato");

            dao.modificaDescrElemMenu(input.getNome(), input.getDescrizione());
        } catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return modificaEffettuata(esitoQuery);
    }

    @PatchMapping("update/costo")
    public ResponseEntity<String> updateCostoElemMenu(@RequestBody ModCostoElMenuDTO input){
        try{
            MenuDAO dao = new MenuDAO(connection);
            // controllo esistenza dell' elemento da modificare
            if(esisteElemMenu(input.getNome()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento non trovato");

            dao.modificaCostoElemMenu(input.getNome(), input.getCosto());
        } catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return modificaEffettuata(esitoQuery);
    }

    @PatchMapping("update/allergeni")
    public ResponseEntity<String> updateAllergeniElemMenu(@RequestBody ModAllergeniElMenuDTO input){
        try{
            MenuDAO dao = new MenuDAO(connection);
            // controllo esistenza dell' elemento da modificare
            if(esisteElemMenu(input.getNome()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento non trovato");

            dao.modificaAllergeniElemMenu(input.getNome(), input.getAllergeni());
        } catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return modificaEffettuata(esitoQuery);
    }

    @PatchMapping("update/categoria")
    public ResponseEntity<String> updateCategElemMenu(@RequestBody ModCategElMenuDTO input){
        try{
            MenuDAO dao = new MenuDAO(connection);
            // controllo esistenza dell' elemento da modificare
            if(esisteElemMenu(input.getNome()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento non trovato");

            dao.modificaCategoriaElemMenu(input.getNome(), input.getCategoria());
        } catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return modificaEffettuata(esitoQuery);
    }

    @PatchMapping("update/postoCategoria")
    public ResponseEntity<String> updatePostoCategElemMenu(@RequestBody ModPostoCategElMenuDTO input){
        try{
            MenuDAO dao = new MenuDAO(connection);
            // controllo esistenza dell' elemento da modificare
            if(esisteElemMenu(input.getNome()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento non trovato");

            dao.modificaPostoCategoriaElemMenu(input.getNome(), input.getPostoCategoria());
        } catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return modificaEffettuata(esitoQuery);
    }

    @DeleteMapping("delete/elementoMenu")
    public ResponseEntity<String> deleteElemMenu(@RequestBody NomeElemMenuDTO input){
        try{
            MenuDAO dao = new MenuDAO(connection);
            // controllo esistenza dell' elemento da eliminare
            if(esisteElemMenu(input.getNome()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento non trovato");

            dao.eliminaElemMenu(input.getNome());
        } catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return eliminazioneEffettuata(esitoQuery);
    }

    @DeleteMapping("delete/tuttoMenu")
    public ResponseEntity<String> deleteElemMenu(){
        try{
            MenuDAO dao = new MenuDAO(connection);

            dao.eliminaTuttoMenu();
        } catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return eliminazioneEffettuata(esitoQuery);
    }

    /*
    Descrizione varchar(500) NOT NULL,
Costo float NOT NULL,
Allergeni varchar(500) NOT NULL,
Categoria varchar(50) DEFAULT NULL,
PostoCategoria integer DEFAULT NULL,
    */
}
