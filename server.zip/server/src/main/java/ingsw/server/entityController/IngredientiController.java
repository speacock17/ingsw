package ingsw.server.entityController;

import ingsw.server.entityDAO.DispensaDAO;
import ingsw.server.entityDAO.IngredientiDAO;
import ingsw.server.entityDAO.MenuDAO;
import ingsw.server.entityDTO.ingredientiDTO.IndividuaIngredienteDTO;
import ingsw.server.entityDTO.ingredientiDTO.IngredientiFormDTO;
import ingsw.server.entityDTO.ingredientiDTO.NomeElemMenuDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.sql.ResultSet;
import java.sql.SQLException;

@RestController
@RequestMapping("controller/ingredienti")
public class IngredientiController extends SuperController{
    public IngredientiController(JdbcTemplate jdbcTemplate) {
        super(jdbcTemplate);
    }

    public String esisteElemMenu(String nome){
        try{
            MenuDAO dao = new MenuDAO(connection);
            // recupero l'intero record dell' elemento del menu
            ResultSet rs = dao.recuperaMenuByNome(nome);
            if(rs == null)
                return FALLIMENTO;
            // estrapolo solo la colonna Nome
            String nomeDaRS = ottieniColonnaDaResultSetSingolaRiga(rs, 1);
            if(nomeDaRS == null)    // se non ho trovato l'elemento cercato
                return FALLIMENTO;
            else{
                if(nomeDaRS.equals(nome)) return nome;
                else return FALLIMENTO;
            }
        }catch (SQLException e){
            return handleSQLException(e);
        }
    }

    private String esisteElemDispensa(String nome){
        try{
            DispensaDAO dao = new DispensaDAO(connection);
            // recupero l'intero record dell' elemento della dispensa
            ResultSet rs = dao.recuperaElemDispensaByNome(nome);
            if(rs == null)
                return FALLIMENTO;
            // estrapolo solo la colonna Nome
            String nomeDaRS = ottieniColonnaDaResultSetSingolaRiga(rs, 1);
            if(nomeDaRS == null)    // se non ho trovato l'elemento cercato
                return FALLIMENTO;
            else{
                if(nomeDaRS.equals(nome)) return nome;
                else return FALLIMENTO;
            }
        }catch (SQLException e){
            return handleSQLException(e);
        }
    }

    private String recuperaUdM(String nome){
        try{
            DispensaDAO dao = new DispensaDAO(connection);
            // recupero l'intero record dell' elemento della dispensa
            ResultSet rs = dao.recuperaElemDispensaByNome(nome);
            if(rs == null)
                return FALLIMENTO;
            // estrapolo solo la colonna UdM
            String uDmDaRS = ottieniColonnaDaResultSetSingolaRiga(rs, 4);
            if(uDmDaRS == null)    // se non ha trovato l'UdM
                return FALLIMENTO;

            else return uDmDaRS;
        }catch (SQLException e){
            return handleSQLException(e);
        }
    }

    @PostMapping("registra")
    public ResponseEntity<String> insertIngredienti(@RequestBody IngredientiFormDTO input){
        // effettua la registrazione nel database di un nuovo ingrediente per elemento menu
        try{
            // accedo alla DAO per recuperare le query legate all'entita' ingredienti
            IngredientiDAO dao = new IngredientiDAO(connection);

            // controllo se esiste in menu l'elemento
            if(esisteElemMenu(input.getElementoMenu()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento menu non trovato");

            // controllo se esiste in dispensa l'elemento da associare
            if(esisteElemDispensa(input.getElementoDispensa()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento dispensa non trovato");

            // recupero l'Unita di misura dell'elemento in dispensa
            String UdM = recuperaUdM(input.getElementoDispensa());

            // controllo che non ci siano stati errori
            if(UdM.equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Errore nel recupero dell' unita di misura nel database");

            // chiedo alla DAO di eseguire la query di inserimento
            dao.inserisciIngredienti(
                input.getQuantita(),
                UdM,
                input.getElementoMenu(),
                input.getElementoDispensa()
            );
        }
        catch(SQLException e){
            // la insert nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return registrazioneEffettuata(esitoQuery);
    }

    @PatchMapping("update/quantita")
    public ResponseEntity<String> updateQuantitaIngredienti(@RequestBody IngredientiFormDTO input){
        // effettua la modifica della quantita dell'elem in dispensa necessaria come ingrediente per l'elemento menu
        try{
            IngredientiDAO dao = new IngredientiDAO(connection);

            // controllo se esiste in menu l'elemento
            if(esisteElemMenu(input.getElementoMenu()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento menu non trovato");

            // controllo se esiste in dispensa l'elemento da associare
            if(esisteElemDispensa(input.getElementoDispensa()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento dispensa non trovato");

            dao.modificaQuantita(input.getElementoMenu(), input.getElementoDispensa(), input.getQuantita());

        }catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return modificaEffettuata(esitoQuery);
    }
    @DeleteMapping("delete/ingrediente")
    public ResponseEntity<String> deleteIngrediente(@RequestBody IndividuaIngredienteDTO input){
        // elimina un ingrediente
        try{
            IngredientiDAO dao = new IngredientiDAO(connection);

            // controllo se esiste in menu l'elemento
            if(esisteElemMenu(input.getElementoMenu()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento menu non trovato");

            // controllo se esiste in dispensa l'elemento da associare
            if(esisteElemDispensa(input.getElementoDispensa()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento dispensa non trovato");

            dao.eliminaIngrediente(input.getElementoMenu(), input.getElementoDispensa());
        }catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return eliminazioneEffettuata(esitoQuery);
    }

    @DeleteMapping("delete/tuttiIngredienti")
    public ResponseEntity<String> deleteTuttiIngredienti(){
        // elimina tutti gli ingredienti di tutti gli elementi del menu
        try{
            IngredientiDAO dao = new IngredientiDAO(connection);

           dao.eliminaTuttiIngredienti();
        }catch(SQLException e){
            // la modifica nel database sollevera' sicuramente un eccezione quindi qui non faccio nulla
            esitoQuery = super.handleSQLException(e);
        }
        // qui effettivamente gestisco l'eccezione (inevitabile)
        return eliminazioneEffettuata(esitoQuery);
    }

    @GetMapping("recupera/ingrediente")
    public ResponseEntity<String> recuperaIngrediente(@RequestBody IndividuaIngredienteDTO input){
        // recupera un ingrediente
        try{
            IngredientiDAO dao = new IngredientiDAO(connection);

            // controllo se esiste in menu l'elemento
            if(esisteElemMenu(input.getElementoMenu()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento menu non trovato");

            // controllo se esiste in dispensa l'elemento da associare
            if(esisteElemDispensa(input.getElementoDispensa()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento dispensa non trovato");

           ResultSet rs = dao.recuperaIngrediente(input.getElementoMenu(), input.getElementoDispensa());
            return ResponseEntity.status(HttpStatus.OK).body(componiDaResultSet(rs));
        }catch(SQLException e){
            esitoQuery = super.handleSQLException(e);
            return ResponseEntity.badRequest().body(esitoQuery);
        }
    }

    @GetMapping("recupera/ingredientiByElementoMenu")
    public ResponseEntity<String> recuperaIngredientiByElemMenu(@RequestBody NomeElemMenuDTO input){
        // recupera gli ingredienti di un elemento del menu
        try{
            IngredientiDAO dao = new IngredientiDAO(connection);

            // controllo se esiste in menu l'elemento
            if(esisteElemMenu(input.getElementoMenu()).equals(FALLIMENTO))
                return ResponseEntity.badRequest().body("Elemento menu non trovato");

            ResultSet rs = dao.recuperaIngredientiByElemMenu(input.getElementoMenu());
            return ResponseEntity.status(HttpStatus.OK).body(componiDaResultSet(rs));
        }catch(SQLException e){
            esitoQuery = super.handleSQLException(e);
            return ResponseEntity.badRequest().body(esitoQuery);
        }
    }

    @GetMapping("recupera/tuttiIngredienti")
    public ResponseEntity<String> recuperaTuttiIngredienti(){
        // recupera tutti gli ingredienti degli elementi del menu
        try{
            IngredientiDAO dao = new IngredientiDAO(connection);

            ResultSet rs = dao.recuperaTuttiIngredienti();
            return ResponseEntity.status(HttpStatus.OK).body(componiDaResultSet(rs));
        }catch(SQLException e){
            esitoQuery = super.handleSQLException(e);
            return ResponseEntity.badRequest().body(esitoQuery);
        }
    }
}
