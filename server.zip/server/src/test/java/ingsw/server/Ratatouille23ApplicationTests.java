package ingsw.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ratatouille23ApplicationTests {

	@Test
	void contextLoads() {
	}

}
