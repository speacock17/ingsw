package ingsw.server.entityDTO.menuDTO;

public class ModCategElMenuDTO {
    private String nome;
    private String categoria;

    public String getNome() {
        return nome;
    }

    public String getCategoria() {
        return categoria;
    }
}
