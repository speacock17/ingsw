package ingsw.server.entityDTO.dispensaDTO;

public class RiduciQtaElemDispDTO {
    private String nome;
    private Float togli;

    public String getNome() {
        return nome;
    }

    public Float getTogli() {
        return togli;
    }

    public RiduciQtaElemDispDTO(String nome, Float togli) {
        this.nome = nome;
        this.togli = togli;
    }
}
