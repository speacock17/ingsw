package ingsw.server.entityDTO.ingredientiDTO;

public class IndividuaIngredienteDTO {
    private String elementoMenu;
    private String elementoDispensa;

    public String getElementoDispensa() {
        return elementoDispensa;
    }

    public String getElementoMenu() {
        return elementoMenu;
    }
}
