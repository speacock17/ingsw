package ingsw.server.entityDTO.bachecaDTO;

public class DeleteAvvisoBacheca {
    private String username;
    private Integer idAvviso;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getIdAvviso() {
        return idAvviso;
    }

    public void setIdAvviso(Integer idAvviso) {
        this.idAvviso = idAvviso;
    }
}
