package ingsw.server.entityDTO.dispensaDTO;

public class ModNomeElemDispDTO {
    private String nome;
    private String newNome;

    public String getNome() {
        return nome;
    }

    public String getNewNome() {
        return newNome;
    }
}
