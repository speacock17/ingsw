package ingsw.server.entityDTO.utenteDTO;

public class ModNomeUtenteDTO {
    String username;
    String nome;

    public String getUsername() {
        return username;
    }

    public String getNome() {
        return nome;
    }
}
