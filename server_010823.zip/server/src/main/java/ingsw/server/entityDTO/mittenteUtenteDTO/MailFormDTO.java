package ingsw.server.entityDTO.mittenteUtenteDTO;

public class MailFormDTO {
    private String username;
    private String oggetto;
    private String testo;

    public MailFormDTO(String username, String oggetto, String testo) {
        this.username = username;
        this.oggetto = oggetto;
        this.testo = testo;
    }

    public String getUsername() {
        return username;
    }

    public String getOggetto() {
        return oggetto;
    }

    public String getTesto() {
        return testo;
    }
}
