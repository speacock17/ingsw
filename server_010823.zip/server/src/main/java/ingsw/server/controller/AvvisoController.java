package ingsw.server.controller;

import ingsw.server.interfacceDAO.AvvisoDAO;
import ingsw.server.entityDTO.avvisoDTO.BodyTextAvvisoDTO;
import ingsw.server.responseBodyBuilder.SendListaStringhe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("controller/avviso")
public class AvvisoController{
    private final AvvisoDAO dao;

    @Autowired
    public AvvisoController(AvvisoDAO dao) {
        this.dao = dao;
    }

    @PostMapping("registra")
    public ResponseEntity<String> inserisciAvviso(@RequestBody BodyTextAvvisoDTO input){
        // effettua la registrazione nel database di un nuovo Avviso
        try{
            dao.inserisciAvviso(input.getOggetto(), input.getTesto());
            return ResponseEntity.ok().body("Registrazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/avviso")
    public ResponseEntity<String> eliminaAvviso(@RequestParam (value = "idAvviso") String idAvviso){
        try {
            dao.eliminaAvvisoById(Integer.valueOf(idAvviso));
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("delete/tuttiAvvisi")
    public ResponseEntity<String> deleteAvviso(){
        try {
            dao.eliminaTuttiAvvisi();
            return ResponseEntity.ok().body("Eliminazione effettuata");
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/avviso")
    public ResponseEntity<String> recuperaAvvisoById(@RequestParam (value = "idAvviso") String idAvviso){
        // restituisce una stringa elencata con i valori IdAvviso, Oggetto, Testo e Data creazione
        try {
            String query = dao.recuperaAvvisoById(Integer.valueOf(idAvviso));
            return ResponseEntity.ok().body(query);
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("recupera/tuttiAvvisi")
    public ResponseEntity<String> recuperaTuttiAvvisi(){
        // restituisce una stringa elencata con i valori di TUTTI gli avvisi
        try{
            List<String> lista = dao.recuperaTuttiAvvisi();
            return ResponseEntity.ok()
                    .body(SendListaStringhe.sendString(lista));
        } catch (DataAccessException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
