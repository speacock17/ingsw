package ingsw.server.interfacceDAO;

import java.util.List;

public interface DispensaDAO {
    /*
        Create table Dispensa(
    Nome varchar(50) NOT NULL,
    Descrizione varchar(500) NOT NULL,
    CostoAcquisto float NOT NULL,
    UdM UnitaDiMisura NOT NULL,
    Quantita float NOT NULL,
    SogliaCritica float NOT NULL,
    */
    public void inserisciDispensa(String nome, String descrizione,
                                      Float costoAcq, String unitaDiMisura,
                                      Float quantita, Float sogliaCritica);
    public void modificaNomeDispensa(String nome, String newNome);
    public void modificaDescrizioneDispensa(String nome, String descrizione);
    public void modificaCostoAcquistoDispensa(String nome, Float costoAcq);
    public void modificaUnitaDiMisuraDispensa(String nome, String unitaDiMisura);
    public void modificaQuantitaDispensa(String nome, Float quantita);
    public void modificaSogliaCriticaDispensa(String nome, Float sogliaCritica);
    public void eliminaDispensaByNome(String nome);
    public void eliminaTuttaDispensa();
    public String recuperaNomeDispensaByNome(String nome);
    public String recuperaDispensaByNome(String nome);
    public String recuperaUdMDispensaByNome(String nome);
    public Float recuperaQuantitaDispensaByNome(String nome);
    public Float recuperaSogliaCriticaDispensaByNome(String nome);
    public List<String> recuperaTuttaDispensa();
}
