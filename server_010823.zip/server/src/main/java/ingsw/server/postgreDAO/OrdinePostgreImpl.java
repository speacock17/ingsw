package ingsw.server.postgreDAO;

import ingsw.server.interfacceDAO.OrdineDAO;
import ingsw.server.springDataMapper.StringDataMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.util.List;

@Repository
public class OrdinePostgreImpl implements OrdineDAO {
    final JdbcTemplate jdbcTemplate;

    @Autowired
    public OrdinePostgreImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /*
        Create table Ordine(
        IdOrdine integer NOT NULL,
        NumeroTavolo integer NOT NULL,
        Prodotto varchar(100) NOT NULL,
    */

    @Override
    public void inserisciOrdine(Integer numeroTavolo, String prodotto) {
        jdbcTemplate.update("INSERT INTO Ordine VALUES (nextval('codOrdine'),?,?)", numeroTavolo, prodotto);
    }

    @Override
    public void modificaNumTavoloById(Integer idOrdine, Integer numeroTavolo) {
        jdbcTemplate.update("UPDATE Ordine SET NumeroTavolo = ? WHERE IdOrdine = ?", numeroTavolo, idOrdine);
    }

    @Override
    public void eliminaOrdiniByTavolo(Integer numTavolo) {
        jdbcTemplate.update("DELETE FROM Ordine WHERE NumeroTavolo = ?", numTavolo);
    }

    @Override
    public void eliminaOrdineById(Integer idOrdine) {
        jdbcTemplate.update("DELETE FROM Ordine WHERE IdOrdine = ?", idOrdine);
    }

    @Override
    public void eliminaTuttiOrdini() {
        jdbcTemplate.update("DELETE FROM Ordine");
    }

    @Override
    public String recuperaUltimoOrdine() {
        List<String> ultimoOrdine = jdbcTemplate.query("SELECT * FROM Ordine WHERE IdOrdine = (SELECT max(IdOrdine) FROM Ordine)", new StringDataMapper());
        return ultimoOrdine.get(0);
    }

    @Override
    public Integer recuperaIdUltimoOrdine(){
        return jdbcTemplate.queryForObject("SELECT IdOrdine FROM Ordine WHERE IdOrdine = (SELECT max(IdOrdine) FROM Ordine)", Integer.class);
    }

    @Override
    public Integer recuperaNumeroTavolo(Integer numeroTavolo) {
        return jdbcTemplate.queryForObject("SELECT DISTINCT NumeroTavolo FROM Ordine WHERE NumeroTavolo = ?", Integer.class, numeroTavolo);
    }

    @Override
    public String recuperaOrdineById(Integer idOrdine) {
        List<String> ordine = jdbcTemplate.query("SELECT * FROM Ordine WHERE IdOrdine = ?", new StringDataMapper(), idOrdine);
        return ordine.get(0);
    }

    @Override
    public List<String> recuperaTuttiOrdini() {
        return jdbcTemplate.query("SELECT * FROM Ordine", new StringDataMapper());
    }

    @Override
    public List<String> recuperaOrdiniByNumTavolo(Integer numeroTavolo) {
        return jdbcTemplate.query("SELECT * FROM Ordine WHERE NumeroTavolo = ?", new StringDataMapper(), numeroTavolo);
    }

    @Override
    public String recuperElemMenuOrdineById(Integer idOrdine) {
        return jdbcTemplate.queryForObject("SELECT Prodotto FROM Ordine WHERE IdOrdine = ?", String.class, idOrdine);
    }

    @Override
    public List<String> recuperaTavoli() {
        return jdbcTemplate.query("SELECT DISTINCT NumeroTavolo FROM Ordine", new StringDataMapper());
    }
}
