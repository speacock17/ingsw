package ingsw.server.postgreDAO;

import ingsw.server.interfacceDAO.BachecaEstesaUtenteDAO;
import ingsw.server.springDataMapper.StringDataMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class BachecaEstesaUtentePostgreImpl implements BachecaEstesaUtenteDAO {
    final JdbcTemplate jdbcTemplate;

    @Autowired
    public BachecaEstesaUtentePostgreImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<String> recuperaTuttaBacheca() {
        return jdbcTemplate.query("SELECT * FROM BACHECAESTESAU", new StringDataMapper());
    }

    @Override
    public List<String> recuperaBachecaByDestinatario(String destinatario) {
        return jdbcTemplate.query("SELECT * FROM BACHECAESTESAU WHERE Destinatario = ?",
                new StringDataMapper(), destinatario);
    }

    @Override
    public List<String> recuperaVisibiliByDestinatario(String destinatario) {
        return jdbcTemplate.query("SELECT * FROM BACHECAESTESAU WHERE Nascosto = false AND Destinatario = ?",
                new StringDataMapper(), destinatario);
    }

    @Override
    public List<String> recuperaNascostiByDestinatario(String destinatario) {
        return jdbcTemplate.query("SELECT * FROM BACHECAESTESAU WHERE Nascosto = true AND Destinatario = ?",
                new StringDataMapper(), destinatario);
    }

    @Override
    public List<String> recuperaVistiByDestinatario(String destinatario) {
        return jdbcTemplate.query("SELECT * FROM BACHECAESTESAU WHERE Visualizzato = true AND Nascosto = false AND Destinatario = ?",
                new StringDataMapper(), destinatario);
    }

    @Override
    public List<String> recuperaVistiNascostiByDestinatario(String destinatario) {
        return jdbcTemplate.query("SELECT * FROM BACHECAESTESAU WHERE Visualizzato = true AND Nascosto = true AND Destinatario = ?",
                new StringDataMapper(), destinatario);
    }
}
