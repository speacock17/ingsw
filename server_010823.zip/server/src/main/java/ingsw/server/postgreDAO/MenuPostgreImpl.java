package ingsw.server.postgreDAO;

import ingsw.server.interfacceDAO.MenuDAO;
import ingsw.server.springDataMapper.StringDataMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class MenuPostgreImpl implements MenuDAO {
    private final JdbcTemplate jdbcTemplate;              // terra' traccia della connessione al Database

    @Autowired
    public MenuPostgreImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /*
    Nome varchar(100) NOT NULL,
    Descrizione varchar(500) NOT NULL,
    Costo float NOT NULL,
    Allergeni varchar(500) NOT NULL,
    Categoria varchar(50) DEFAULT NULL,
    PostoCategoria integer DEFAULT NULL,
     */

    @Override
    public void inserisciMenu(String nome, String descrizione, Float costo, String allergeni, String categoria) {
        jdbcTemplate.update("INSERT INTO MENU VALUES (?,?,?,?,?)",
                nome, descrizione, costo, allergeni, categoria);
    }

    @Override
    public void modificaNomeMenu(String nome, String newNome) {
        jdbcTemplate.update("UPDATE MENU SET Nome = ? WHERE Nome = ?", newNome, nome);
    }

    @Override
    public void modificaDescrizioneMenu(String nome, String descrizione) {
        jdbcTemplate.update("UPDATE MENU SET Descrizione = ? WHERE Nome = ?", descrizione, nome);
    }

    @Override
    public void modificaCostoMenu(String nome, Float costo) {
        jdbcTemplate.update("UPDATE MENU SET Costo = ? WHERE Nome = ?", costo, nome);
    }

    @Override
    public void modificaAllergeniMenu(String nome, String allergeni) {
        jdbcTemplate.update("UPDATE MENU SET Allergeni = ? WHERE Nome = ?", allergeni, nome);
    }

    @Override
    public void modificaPostoCategoriaMenu(String nome, Integer postoCategoria) {
        jdbcTemplate.update("UPDATE MENU SET PostoCategoria = ? WHERE Nome = ?", postoCategoria, nome);
    }

    @Override
    public void modificaCategoriaMenu(String nome, String categoria) {
        jdbcTemplate.update( "UPDATE MENU SET Categoria = ? WHERE Nome = ?", categoria, nome);
    }

    @Override
    public void eliminaMenuByNome(String nome) {
        jdbcTemplate.update("DELETE FROM MENU WHERE Nome = ?", nome);
    }

    @Override
    public void eliminaTuttoMenu() {
        jdbcTemplate.update("DELETE FROM MENU");
    }

    @Override
    public List<String> recuperaTuttoMenu() {
        return jdbcTemplate.query("SELECT * FROM MENU", new StringDataMapper());
    }

    @Override
    public String recuperaMenuByNome(String nome) {
        List<String> menu = jdbcTemplate.query("SELECT * FROM MENU WHERE Nome = ?", new StringDataMapper(), nome);
        return menu.get(0);
    }

    @Override
    public List<String> recuperaElementiMenuSenzaCategoria() {
        return jdbcTemplate.query("SELECT * FROM MENU WHERE Categoria IS NULL", new StringDataMapper());
    }

    @Override
    public Integer ottieniNumeroElemInCategoria(String categoria) {
        return jdbcTemplate.queryForObject("SELECT count(PostoCategoria) FROM MENU WHERE Categoria = ?", Integer.class, categoria);
    }

    @Override
    public List<String> recuperaMenuByCategoria(String categoria) {
        return jdbcTemplate.query("SELECT * FROM MENU WHERE Categoria = ? ORDER BY PostoCategoria", new StringDataMapper(), categoria);
    }

    @Override
    public String recuperaNomeMenuByNome(String nome) {
        return jdbcTemplate.queryForObject("SELECT Nome FROM Menu WHERE Nome = ?", String.class, nome);
    }

    @Override
    public Integer recuperaPostoMenuByCategoria(String categoria) {
        return jdbcTemplate.queryForObject("SELECT max(PostoCategoria) FROM MENU WHERE Categoria = ?", Integer.class, categoria);
    }
}
