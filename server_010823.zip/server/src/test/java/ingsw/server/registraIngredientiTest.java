package ingsw.server;

import ingsw.server.interfacceDAO.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataAccessException;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class registraIngredientiTest {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private MenuDAO menuDao;
    @Autowired
    private DispensaDAO dispensaDao;
    @Autowired
    private IngredientiDAO ingredientiDao;
    @Autowired
    private UtenteDAO utenteDao;

    private final String url = "http://localhost:8080/controller/ingredienti/registra";
    private final String elementoMenu = "elementoTest";
    private final String elementoDispensa = "dispensaTest";
    private final Float quantitaValida = Float.valueOf(1);
    private final Float quantitaNonValida = Float.valueOf(0);
    private String username = "superuser";
    private String token;

    private String generaBody(Float quantita, String elementoMenu, String elementoDispensa){
        return "{\"quantita\":\"" + quantita + "\",\"elementoMenu\": \""
                + elementoMenu + "\",\"elementoDispensa\":\"" + elementoDispensa + "\"}";
    }

    private MockHttpServletRequestBuilder generaRichiesta(String url, String body){
        return MockMvcRequestBuilders.post(url)
                .contentType(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + token)
                .content(body);
    }

    private void autentica(String username, String password) throws Exception{
        // effettuo l'autenticazione
        String body = "{\"login\":\"" + username + "\",\"password\":\"" + password +"\"}";
        MockHttpServletRequestBuilder richiesta = MockMvcRequestBuilders
                .post("http://localhost:8080/auth")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body);

        ResultActions accesso = mockMvc.perform(richiesta)
                .andExpect(status().isOk());

        String tokenResponse = accesso.andReturn().getResponse().getContentAsString();
        token = tokenResponse.substring(16, tokenResponse.length()-2);
    }

    @BeforeEach
    void init(){
        try {
            utenteDao.inserisciUtente("superuser", "superuser", username , "superuser", "Admin");

            autentica(username, username);

            menuDao.inserisciMenu(elementoMenu, "elemento di test",
                    Float.valueOf(0), "allergeni di test", null);

            dispensaDao.inserisciDispensa(elementoDispensa, "elemento dispensa di test",
                    Float.valueOf(0), "Litro", Float.valueOf(2), Float.valueOf(1));
        } catch (Exception e){
            System.out.println("ERRORE NELLA FUNZIONE init(): " + e.getMessage());
        }
    }

    @Test
    @DisplayName("Quantita valida, elemento menu esiste, elemento dispensa esiste: Ingrediente registrato con successo")
    void quantitaValidaElementoMenuEsisteElementoDispensaEsisteTest(){
        // ARRANGE
        String body = generaBody(quantitaValida, elementoMenu, elementoDispensa);

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isOk());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Quantita non valida, elemento menu esiste, elemento dispensa esiste: Ingrediente non registrato")
    void quantitaNonValidaElementoMenuEsisteElementoDispensaEsisteTest(){
        // ARRANGE
        String body = generaBody(quantitaNonValida, elementoMenu, elementoDispensa);

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: quantita non valida"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Quantita valida, elemento menu non esiste, elemento dispensa esiste: Ingrediente non registrato")
    void quantitaValidaElementoMenuNonEsisteElementoDispensaEsisteTest(){
        // ARRANGE
        String body = generaBody(quantitaValida, "nonEsisto", elementoDispensa);

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Elemento menu non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Quantita valida, elemento menu esiste, elemento dispensa non esiste: Ingrediente non registrato")
    void quantitaValidaElementoMenuEsisteElementoDispensaNonEsisteTest(){
        // ARRANGE
        String body = generaBody(quantitaValida, elementoMenu, "nonEsisto");

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Elemento dispensa non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Quantita nulla, elemento menu esiste, elemento dispensa esiste: Ingrediente non registrato")
    void quantitaNullaElementoMenuEsisteElementoDispensaEsisteTest(){
        // ARRANGE
        String body = "{\"elementoMenu\": \"" + elementoMenu +
                "\",\"elementoDispensa\":\"" + elementoDispensa + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: quantita non valida"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Quantita valida, elemento menu nullo, elemento dispensa esiste: Ingrediente non registrato")
    void quantitaValidaElementoMenuNulloElementoDispensaEsisteTest(){
        // ARRANGE
        String body = "{\"quantita\": \"" + quantitaValida +
                "\",\"elementoDispensa\":\"" + elementoDispensa + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Elemento menu non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Quantita valida, elemento menu esiste, elemento dispensa nullo: Ingrediente non registrato")
    void quantitaValidaElementoMenuEsisteElementoDispensaNulloTest(){
        // ARRANGE
        String body = "{\"quantita\": \"" + quantitaValida +
                "\",\"elementoMenu\":\"" + elementoMenu + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Elemento dispensa non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Quantita vuota, elemento menu esiste, elemento dispensa esiste: Ingrediente non registrato")
    void quantitaVuotaElementoMenuEsisteElementoDispensaEsisteTest(){
        // ARRANGE
        String body = "{\"quantita\": \"" + "" + "\", \"elementoMenu\": \"" + elementoMenu +
                "\",\"elementoDispensa\":\"" + elementoDispensa + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: quantita non valida"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Quantita valida, elemento menu vuoto, elemento dispensa esiste: Ingrediente non registrato")
    void quantitaValidaElementoMenuVuotoElementoDispensaEsisteTest(){
        // ARRANGE
        String body = "{\"quantita\": \"" + quantitaValida + "\", \"elementoMenu\": \"" + "" +
                "\",\"elementoDispensa\":\"" + elementoDispensa + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Elemento menu non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Test
    @DisplayName("Quantita valida, elemento menu esiste, elemento dispensa vuoto: Ingrediente non registrato")
    void quantitaValidaElementoMenuEsisteElementoDispensaVuotoTest(){
        // ARRANGE
        String body = "{\"quantita\": \"" + quantitaValida + "\", \"elementoMenu\": \"" + elementoMenu +
                "\",\"elementoDispensa\":\"" + "" + "\"}";

        MockHttpServletRequestBuilder richiesta = generaRichiesta(url, body);

        // ACT E ASSERT
        try {
            mockMvc.perform(richiesta)
                    .andExpect(status().isBadRequest())
                    .andExpect(MockMvcResultMatchers.content().string("Errore: Elemento dispensa non trovato"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @AfterEach
    void done(){
        try {
            utenteDao.eliminaUtenteByUsername(username);
            menuDao.eliminaMenuByNome(elementoMenu);
            dispensaDao.eliminaDispensaByNome(elementoDispensa);
        } catch (DataAccessException e){
            System.out.println("ERRORE NELLA FUNZIONE done(): " + e.getMessage());
        }
    }
}
