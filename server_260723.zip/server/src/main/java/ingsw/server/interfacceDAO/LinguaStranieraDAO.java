package ingsw.server.interfacceDAO;

import java.util.List;

public interface LinguaStranieraDAO {
    /*
    Create table LinguaStraniera(
        Lingua varchar(50) NOT NULL,
        NomeProdotto varchar(100) NOT NULL,
        DescrizioneProdotto varchar(500) NOT NULL,
        ElementoMenu varchar(100) NOT NULL,
     */
    public void inserisciLinguaStraniera(String lingua,
                                         String nomeProdotto,
                                         String descrizioneProd,
                                         String elementoMenu);
    public void modificaLinguaElemLingStr(String elemMenu, String lingua);
    public void modificaNomeLingStr(String elemMenu, String nomeProdotto);
    public void modificaDescrElemMenu(String elemMenu, String descrizioneProd);
    public void eliminaElemMenu(String elemMenu);
    public void eliminaTuttoMenu();
    public String recuperaElemLinguaStr(String elemMenu);
    public List<String> recuperaTuttaLinguaStraniera();
}
