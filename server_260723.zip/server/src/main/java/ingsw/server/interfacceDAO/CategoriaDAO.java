package ingsw.server.interfacceDAO;

import java.util.List;

public interface CategoriaDAO {
    /*
        Create table Categoria(
    Nome varchar(50) NOT NULL,
    PostoMenu integer DEFAULT NULL,
     */
    public void inserisciCategoria(String nome, Integer postoMenu);
    public void modificaNomeCategoria(String nome, String newName);
    public void modificaPostoCategoria(String nome, Integer postoMenu);
    public void eliminaCategoriaByNome(String nome);
    public void eliminaTutteCategorie();
    public Integer recuperaUltimoPosto();
    public String recuperaCategoriaByNome(String nome);
    public List<String> recuperaTutteCategorie();
}
